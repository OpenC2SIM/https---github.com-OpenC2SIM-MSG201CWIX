The C2SIMdashboard is a display panel for C2SIM, intended to met the 
requirements of FMN Spiral 5 (now 6) for developers user to 
monitor the running C2SIM environment with minmal details. It was derived
largely from the C2SIMGUI editor used for C2SIM development.

The C2SIMdashboard can be run by invoking in this directory. The first 
parameter of the command to run in the IP address of the server used.

It displays latest C2SIM message summary for each C2SIM client in STOMP.

for Linux and MacOSX, on command line: ./runDashboard
(you may need to first run on command line "chmod +x ./runDashboard")

for Microsoft Windows: runC2SIMdashboard.bat

This is newly developed software so bugs can be expected.
Please report any problems to mpullen@gmu.edu and include screen shots.

