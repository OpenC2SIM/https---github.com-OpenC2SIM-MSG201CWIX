/*----------------------------------------------------------------*
|   Copyright 2009-2023 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

// Version of C2SIMGUI C2SIM Editor that works with REST and STOMP
// and features controls for the Reference Implementation C2SIM Server

// capable of loading, parsing, editing, and pushing C2SIM
// reports and orders using REST

// command line parameter 'true' enables debug printing

package edu.gmu.netlab;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.util.Properties;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Date;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import javax.swing.*;
import javax.swing.border.*;

import com.jaxfront.core.dom.DOMBuilder;
import com.jaxfront.core.dom.Document;
import com.jaxfront.core.help.HelpEvent;
import com.jaxfront.core.help.HelpListener;
import com.jaxfront.core.schema.ValidationException;
import com.jaxfront.core.ui.TypeVisualizerFactory;
import com.jaxfront.core.util.LicenseErrorException;
import com.jaxfront.core.util.URLHelper;
import com.jaxfront.core.util.io.BrowserControl;
import com.jaxfront.core.util.io.cache.XUICache;
import com.jaxfront.pdf.PDFGenerator;
import com.jaxfront.swing.ui.editor.EditorPanel;
import com.jaxfront.swing.ui.editor.ShowXMLDialog;

import java.util.*;
import java.net.*;

// DOM and XPATH
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import javax.xml.parsers.*;
import javax.xml.namespace.NamespaceContext;
import edu.gmu.c4i.c2simclientlib2.*;
import static edu.gmu.netlab.Subscriber.bml;
import org.w3c.dom.*;

// our ClientLib
import edu.gmu.c4i.c2simclientlib2.*;

public class C2SIMcontrol extends JFrame implements WindowListener, HelpListener, 
    ItemListener, ActionListener {
    
    // Version (compatible C2SIM_SMX_LOX_CWIX2023v2.xsd)
    public static String version = "1.0.6";

/**
 * Based on BMLC2 GUI (Initially BMLGUI) finally C2SIMGUI)
 * 
 * Started : 3/5/2023
 * This project displays and generates C2SIM SystemMessage for
 * user control of a C2SIM Coalition of C2 and simulation systems.
 * It does not provide controls for technical operation; rather
 * displays and generates the following messages:
 *  CheckpointRestore
 *  CheckpointSave
 *  InitializationComplete
 *  Magic Move
 *  PausePlayback
 *  PauseRecording
 *  PauseScenario
 *  PlaybackRealtimeMultipleReport
 *  PlaybackStatusReport
 *  RequestPlaybackRealtimemultiple
 *  RequestPlaybackStatus
 *  RequestRecordingStatus
 *  RequestSimulationRealtimeMultiple
 *  ResetScenario
 *  ResumeRecording
 *  ResumeScenario
 *  SetPlaybackRealtimemultiple
 *  SetSiulationRelatimemultiple
 *  ShareScenario
 *  SimulationRealtimeMultipleReport
 *  StartPlayback
 *  StartRecording
 *  StopPlayback
 *  StopScenario
 *  SubmitInitialization
 * 
 * @author      J. M. Pullen, C4I & Cyber Center, George Mason University
 * @since       3/5/2023
 */
    // set true to print debug info
    static boolean debugMode = false;
    
    // Main Application's Frame Height and Width
    private final static int WINDOW_HEIGHT = 500; 
    private final static int WINDOW_WIDTH = 520; 

    // Main Frame Panels
    JPanel connectionPanel = new JPanel();

    private JPanel groupCommControl = new JPanel();
    private JPanel recorderControl = new JPanel();
    private JPanel playerControl = new JPanel();
    
    // c2UserControlPanel
    private JPanel c2UserControlTitle = new JPanel();

    // Report Info Combo Box
    public JLabel subscriberStatusLabel;
    public JLabel initStatusLabel;
    public JLabel serverStatusLabel;

    // message types
    String c2simProtocol = "SISO-STD-C2SIM";
    String c2simProtocolVersion = "CWIX2023v1.0.2";
    String c2simPath = "C2SIMServer/c2sim";
    String conversationID = "";
    String c2simRootTag = "MessageBody";
    String c2simOrderReportDomain = "DomainMessageBody";
    String c2simSystemMessageDomain = "SystemMessageBody";
    String c2simInitializationDomain = "C2SIMInitializationBody";
    String objectInitializationDomain = "ObjectInitializationBody";
    String recordStatus = "UNKNOWN";
    String playerStatus = "UNKNOWN";
    String startupInitialization = null;
    String lateJoinerInitialization = null;
    String defaultC2simProtocolVersion = "1.0.1";
    public boolean stompIsConnected = false;
    
    // hide Player radio buttons
    void hidePlayerButtons(){
        if(playerGroup != null)playerGroup.clearSelection();
        playerStopButton.setVisible(false);
        playerStartButton.setVisible(false);
        playerPauseButton.setVisible(false);
        playerResumeButton.setVisible(false);
    }

    // hide Recorder radio buttons
    void hideRecorderButtons(){
        if(recorderGroup != null)recorderGroup.clearSelection();
        recorderStopButton.setVisible(false);
        recorderStartButton.setVisible(false);
        recorderPauseButton.setVisible(false);
        recorderResumeButton.setVisible(false);
    }

    // hide Server radio buttons
    void hideServerButtons(){
        if(serverGroup != null)serverGroup.clearSelection();
        serverStopButton.setVisible(false);
        serverStartButton.setVisible(false);
        serverInitializeButton.setVisible(false);
        serverShareButton.setVisible(false);
        serverResumeButton.setVisible(false);
        serverResetButton.setVisible(false);
        serverPauseButton.setVisible(false);
    }
    
    public boolean c2simProtocolOK(String testProtocol){
        return (testProtocol.compareTo(C2SIMProtocolVsnMax) <= 0) &&
               (testProtocol.compareTo(C2SIMProtocolVsnMin) >= 0);
    }// end c2simProtocolOK()
    
    static String osName;
	
    public static C2SIMcontrol bml;     // reference for main GUI frame
  
    public static Webservices ws;       // to access REST/STOMP
    
    public Subscriber subscriber = null;// for STOMP connection

    /** The name of the resource file. "C2SIMGUI.properties" */
    public static String c2mlResources = "bmlc2gui.properties"; 

    // state information
    String bmlString = new String();    // C2SIm Document converted to a csv
    String[] bmlStringArray;            // array from bmlstring
    static boolean platformIsWindows;
    static boolean platformIsLinux;
    static String coalitionState = "UNKNOWN";

    public static org.w3c.dom.Document w3cBmlDom;
	
    private XPathFactory xpathFactory = null;
    private XPath xpath = null;
    private DocumentBuilderFactory w3cDocFactory = null;
    private DocumentBuilder w3cDocBuilder = null;

    public volatile Thread threadSub;
    public java.util.concurrent.LinkedBlockingQueue<String> localQueue =
        new java.util.concurrent.LinkedBlockingQueue<>();;// used when not online
  
    // Variables to hold configuration values
    static String startSubscribed = "1";     // 1 or 0 start control subscribed to server                // namespace string for IBML09 XML documents
    static String cbmlns;                    // namespace string for CBML XML documents
    static String submitterID ="C2SIMcontrol";// Client SubmitterID variable
    static String serverName;                // Server DNS name
    static String serverPassword = "";     // InitC2SIM ServerPassword variable
    static String runCoalitionControl = "0"; // showboth panels
    static String C2SIMProtocolVsnMin = "CWIX2023v1.0.2";
    static String C2SIMProtocolVsnMax = "CWIX2023v1.0.2";
    static String C2SIMProtocolVersionSend;  // version to send
    static String restPort = "8080";         // assigned port for RESTful transaction
    static String stompPort = "61613";       // assigned port for STOMP connection
    static String lateJoinerMode = "1";      // 1 or 0 - to run in late joiner mode or not
    
    static String playbackTimescale = "1.0";   // speedup factor          
    static String scenarioTimescale = "1.0"; 
    
    static String playbackSubmitter;         // identifies source of XML message
    static String delimiter = "/";           // set to "/" for Unix
    static String schemaFolderLocation;      // schema work folder
    static String xuiFolderLocation;         // Location of XUI file
    static String localAddress;              // our IP address
    static String c2simInitSchemaLocation;   // Initialize subdirectory

    NamespaceContext nsContext= new NamespaceContext() {
        public Iterator getPrefixes(String namespaceURI) {
            return null;
        }
        public String getPrefix(String namespaceURI) {
            return null;
        }
        public String getNamespaceURI(String prefix) {
                String uri = null;
        if (prefix.equals("CBML"))
            uri = "urn:sisostds:bml:coalition:draft:cbml:1";
            return uri;
        }
    };
	
    /**
    * Constructor (no-arg only)
    */
    public C2SIMcontrol() {
        super();
        init();
    
        // XPath
        xpathFactory = XPathFactory.newInstance();
        xpath = xpathFactory.newXPath();

        // webservices
        ws = new Webservices(this);
        
        // add shutdownHook for subscriber
        Runtime.getRuntime().addShutdownHook(new shutdownStomp());
        
        // create forms to display controls
        buildBox();
        this.pack();
        this.setVisible(true);
        
    }// end C2SIMcontrol()
    
    // "PolyMap" is a HashMap of ArrayLists
    // insert one PolyMap entry with key 'association'
    // This version is for HashMap NextStates
    void putPolyMapN(
        String association, String systemMessageType){
        // if PolyMapN contains entry keyed to 'association',
        // add this systemMessageType to ArrayList for the association 
        ArrayList<String> tryList = nextStates.get(association);
        if(tryList == null)tryList = new ArrayList<String>();
        if(nextStates == null || nextStates.isEmpty())
            tryList.add(systemMessageType);
        else
            tryList.add(systemMessageType);
        nextStates.put(association,tryList);
    }// end putPolyMapN()
    
    ArrayList<String> getPolyMapN(String association) {
        
        ArrayList<String> result = nextStates.get(association);
        return result;
    }// end getPolyMapN()
    
    JButton[] buttons;
    void loadNextStates() {
        
        // make an array for JButtons containing as many as we may need
        buttons = new JButton[5];
        buttons[0] = new JButton();
        buttons[1] = new JButton();
        buttons[2] = new JButton();
        buttons[3] = new JButton();
        buttons[4] = new JButton();
        
        // for each currentState, put possible SystemMessage (large
        // number of Paused is because all play or record starts there)
        putPolyMapN("Paused","CheckpointRestore");
        putPolyMapN("Paused","CheckpointSave");
        putPolyMapN("Initializing","Reset");
        putPolyMapN("Initializing","InitializationComplete");
        putPolyMapN("Running","MagicMove");
        putPolyMapN("Paused","PausePlayback");
        putPolyMapN("Running","PauseRecording");
        putPolyMapN("Running","PauseScenario");
        putPolyMapN("Paused","PlaybackRealtimeMultipleReport");
        putPolyMapN("Paused","PlaybackStatusReport");
        putPolyMapN("Paused","RecordingStatusReport");
        putPolyMapN("Paused","RequestPlaybackRealtimeMultiple");
        putPolyMapN("Paused","RequestPlaybackStatus");
        putPolyMapN("Paused","RequestRecordingStatus");
        putPolyMapN("Paused","RequestSimulationRealtimeMultiple");
        putPolyMapN("Initializing","ResetScenario");
        putPolyMapN("Initialized","ResumePlayback");
        putPolyMapN("Paused","ResumeRecording");
        putPolyMapN("Paused","ResumeScenario");
        putPolyMapN("Paused","SetPlaybackRealtimeMulltiple");
        putPolyMapN("Paused","SetSimulationRealtimeMultiple");
        putPolyMapN("Initializing","ShareScenario");
        putPolyMapN("Paused","SimulationRealtimeMultipleReport");
        putPolyMapN("Paused","StartPlayback");
        putPolyMapN("Paused","StartRecording");
        putPolyMapN("Initialzed","StartScenario");
        putPolyMapN("Paused","StopPlayback");
        putPolyMapN("Paused","StopRecording");
        putPolyMapN("Paused","StopScenario");
        putPolyMapN("Running","StopScenario");
        putPolyMapN("Paused","StopScenario");
        putPolyMapN("Uninitialized","SubmitInitialization");
        
    }// end loadNextStates()
    

    public static void main(String[] args) {	
    
        System.out.println("Version " + version + " of C2SIMcontrol panel");

        // mandatory command-line argument: server address
        if(args.length == 0){
            showInfoPopup("ERROR",
                "SERVER NETWORK ADDRESS REQUIRED AS COMMAND-LINE ARGUMENT");
            return;
        }
        serverName = args[0];
        serverPassword = "";
        if(args.length > 1)
            serverPassword = args[1];
        if(args.length > 2){
            runCoalitionControl = args[2]; 

            // debug output
            if(args.length > 3)
              debugMode = args[4].equals("true");
        }

        // determine host platform
        osName = System.getProperty("os.name");
        if(debugMode)printDebug("PLATFORM:"+osName);
        platformIsWindows = osName.contains("Windows");
        platformIsLinux = osName.contains("Linux");
        if(platformIsWindows) {
            if(debugMode)printDebug("OS Windows");
            delimiter = "\\";
        }
        else {
            if(debugMode)printDebug("OS Unix-like");
            c2mlResources = "bmlc2guiUnix.properties";
            delimiter = "/";
        }
        try{
            localAddress = InetAddress.getLocalHost().getHostAddress();
        } catch(UnknownHostException uhe) {
            printError("can't get local host address");
            return;
        }

        // Set look and feel based on OS type
        try {
            if (platformIsWindows) { 
                // For Windows, use JGoodies looks
                //UIManager.setLookAndFeel(new com.jgoodies.looks.windows.WindowsLookAndFeel());	
                UIManager.setLookAndFeel("com.jgoodies.looks.windows.WindowsLookAndFeel");	

        } else {
                // For Linux, etc., use GTK+ looks
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("com.sun.java.swing.plaf.gtk.GTKLookAndFeel".equals(info.getClassName())) {   
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                } 
            }	    	
        }
        } catch (Exception e) {
            printError("Error setting look and feel: " + e.getMessage());
            return;
        }
        
        // get local directory
        c2simInitSchemaLocation = System.getProperty("user.dir") +"/Initialize";

        // startup C2SIMcontrol 
        bml = new C2SIMcontrol();

        // subscribe to server
        if(startSubscribed.equals("1"))
            bml.startServerSubscribeThread();

    }// end main()
    
    // make Init schema path available
    String getSchemaDirectory(){return c2simInitSchemaLocation;}

    /**
     * print argument only if in debug mode
     */
    static void printDebug(String toPrint)
    {
      System.out.println(toPrint);
    }
    static void printDebug(int toPrint)
    {
      System.out.println(toPrint);
    }
    
    /**
     *  print argument to System.err
     */
    public static void printError(String toPrint){
        System.err.println("ERROR:"+toPrint);
    }

    /**
     * Initialize the window frame GUI Frame (Widgets, Layouts, and ActionListeners)
     */
    public void init() {
        try {			
            // Add the title of the C2SIMGUI Frame, also specify sizes and display it
            setTitle("C2SIM Control version " + version);
            if(runCoalitionControl != null)
                setPreferredSize(new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT));	
            else setPreferredSize(new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT/2));
            setLayout(new BorderLayout());
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            // create overall Panel
            JPanel controlBox = new JPanel();
            add(controlBox);
           // controlBox.setBorder(BorderFactory.createLineBorder(Color.RED));
        }
        catch (Exception e){
            printError("Exception:" + e.getMessage());
        }
    
    } // end init()
    
    // setup formats for control panels
    JPanel c2UserControlPanel = new JPanel();
    JPanel coalitionRow0;
    JPanel coalitionRow1;
    JPanel coalitionRow2;
    JPanel coalitionRow3;
    JPanel coalitionRow4;
    JLabel spacer;
    JLabel playerState = new JLabel("Player state: UNKNOWN" + "   ");
    JLabel recordState = new JLabel("Recorder state: UNKNOWN" + "   ");
    HashMap<String,ArrayList<String>> nextStates = 
        new HashMap<String,ArrayList<String>>();
    JLabel serverCoalitionState;
    JLabel c2ControlTitle;
    JPanel serverRow0;
    JPanel serverRow1;
    JPanel serverRow2;
    JPanel serverRow3;
    JPanel serverRow4;
    JPanel serverRow5;
    JPanel serverRow6;
    JPanel serverRow7;
    Float playerSpeedup = new Float(1.0);
    JTextField newPlayerSpeedup = new JTextField(4);
    JLabel playerSpeedupValue = new JLabel(playbackTimescale);
    Float coalitionSpeedup = new Float(1.0);
    JTextField newCoalitionSpeedup = new JTextField(4);
    JLabel coalitionSpeedupValue = new JLabel(scenarioTimescale);
    JLabel serverControlTitle;
    JPanel coalitionButtonPanel;
    JLabel coalitionControlText;
    InitC2SIM initC2sim;
    ButtonGroup playerGroup;
    ButtonGroup serverGroup;
    ButtonGroup recorderGroup;
    ButtonGroup checkpointGroup;
    JLabel recorderControlText;
    
    // radio buttons
    public JRadioButton playerStartButton = new JRadioButton("PLAY");
    public JRadioButton playerStopButton = new JRadioButton("STOP");
    public JRadioButton playerPauseButton = new JRadioButton("PAUSE");;
    public JRadioButton playerResumeButton = new JRadioButton("RESUME");
    public JRadioButton recorderStopButton = new JRadioButton("STOP");
    public JRadioButton recorderStartButton = new JRadioButton("RUN");
    public JRadioButton recorderPauseButton = new JRadioButton("PAUSE");
    public JRadioButton recorderResumeButton = new JRadioButton("RESUME");
    public JRadioButton serverPauseButton = new JRadioButton("PAUSE");
    public JRadioButton serverShareButton = new JRadioButton("SHARE");
    public JRadioButton serverStopButton = new JRadioButton("STOP");
    public JRadioButton serverStartButton = new JRadioButton("RUN");
    //public JRadioButton serverUninitButton = new JRadioButton("UNINIT");
    public JRadioButton serverInitializeButton = new JRadioButton("INITIALIZE");
    public JRadioButton serverResumeButton = new JRadioButton("RESUME");
    public JRadioButton serverResetButton = new JRadioButton("RESET");
    public JRadioButton checkpointRestoreButton = new JRadioButton("CHECKPOINT REVERT");
    public JRadioButton checkpointSaveButton = new JRadioButton("CHECKPOINT SAVE");
        
    void buildBox(){
        // parameters for whole frame
        Font titleFont = new Font("LucidaGrande",Font.BOLD,18);   
        
        // c2UserControlPanel
        c2UserControlPanel = new JPanel();
        c2UserControlPanel.setLocation(0,0);
        c2UserControlPanel.setFont(titleFont);

        // setup c2UserControlPanel
        c2UserControlPanel.setBorder(BorderFactory.createLineBorder(Color.black));
                
        // upper panel title
        coalitionRow1 = new JPanel();
        c2ControlTitle = new JLabel("C2SIM C2 USER CONTROL FOR SERVER " + serverName);
        c2ControlTitle.setFont(titleFont);
        coalitionRow1.add(c2ControlTitle);
        c2UserControlPanel.add(coalitionRow1);
        
        // Coalition state
        coalitionRow2 = new JPanel();
        serverCoalitionState = new JLabel(
            "Simulation Coalition state: " + coalitionState);
        coalitionRow2.add(serverCoalitionState);
        c2UserControlPanel.add(coalitionRow2);
               
        // Player state
        coalitionRow3 = new JPanel();
        coalitionRow3.add(playerState);
        JLabel changePlay = new JLabel(" change: ");
            coalitionRow3.add(changePlay);
        coalitionRow3.add(playerStartButton);
        coalitionRow3.add(playerStopButton);
        coalitionRow3.add(playerPauseButton);
        coalitionRow3.add(playerResumeButton);
        playerGroup = new ButtonGroup();
        playerGroup.add(playerStartButton);
        playerGroup.add(playerStopButton);
        playerGroup.add(playerPauseButton);
        playerGroup.add(playerResumeButton);
        playerStartButton.addActionListener(this);
        playerStopButton.addActionListener(this);
        playerPauseButton.addActionListener(this);
        playerResumeButton.addActionListener(this);
        c2UserControlPanel.add(coalitionRow3);
        
        // Player speedup
        coalitionRow4 = new JPanel();
        JLabel playerSpeedupLabel = new JLabel("Player speedup:");
        JLabel enterHere = new JLabel(" enter here to change:");
        coalitionRow4.add(playerSpeedupLabel);
        coalitionRow4.add(playerSpeedupValue);
        coalitionRow4.add(enterHere);
        coalitionRow4.add(newPlayerSpeedup);
        newPlayerSpeedup.addActionListener(this);
        c2UserControlPanel.add(coalitionRow4);

        // prepare for deployment
        hidePlayerButtons();
        
        // server control  
        // locate panel in frame
        if(runCoalitionControl.equals("1")) {
            
            // lower panel title
            serverRow0 = new JPanel();
            JLabel filler = new JLabel(" ");
            serverRow0.add(filler);
            c2UserControlPanel.add(serverRow0);
            serverRow1 = new JPanel();
            serverControlTitle = new JLabel("C2SIM SERVER CONTROL");
            serverControlTitle.setFont(titleFont);
            serverRow1.add(serverControlTitle);
            c2UserControlPanel.add(serverRow1);

            // coalition/server state
            serverRow2 = new JPanel();
            coalitionControlText = 
                new JLabel("Simulation Coalition state: " + coalitionState);
            serverRow2.add(coalitionControlText);
            JLabel changeTo = new JLabel(" change: ");
            serverRow2.add(changeTo);
            serverRow2.add(serverStartButton);
            serverRow2.add(serverInitializeButton);
            serverRow2.add(serverShareButton);
            serverRow2.add(serverPauseButton);
            serverRow2.add(serverResumeButton);
            serverRow2.add(serverStopButton);
            serverRow2.add(serverResetButton);
            serverGroup = new ButtonGroup();
            serverGroup.add(serverStartButton);
            serverGroup.add(serverInitializeButton);
            serverGroup.add(serverShareButton);
            serverGroup.add(serverResetButton);
            serverGroup.add(serverStopButton);
            serverGroup.add(serverPauseButton);
            serverGroup.add(serverResumeButton);
            serverGroup.add(serverStopButton);
            serverStartButton.addActionListener(this);
            serverStopButton.addActionListener(this);
            serverPauseButton.addActionListener(this);
            serverResumeButton.addActionListener(this);
            serverShareButton.addActionListener(this);
            serverInitializeButton.addActionListener(this);
            serverResetButton.addActionListener(this);
            c2UserControlPanel.add(serverRow2);
            
            // recorder state
            serverRow3 = new JPanel();
            serverRow3.add(recordState);
            JLabel recordChangeTo = new JLabel(" change: ");
            serverRow3.add(recordChangeTo);
            serverRow3.add(recorderStartButton);
            serverRow3.add(recorderResumeButton);
            serverRow3.add(recorderPauseButton);
            serverRow3.add(recorderStopButton);
            recorderGroup = new ButtonGroup();
            recorderGroup.add(recorderStartButton);
            recorderGroup.add(recorderStopButton);
            recorderGroup.add(recorderPauseButton);
            recorderGroup.add(recorderResumeButton);
            recorderStartButton.addActionListener(this);
            recorderStopButton.addActionListener(this);
            recorderPauseButton.addActionListener(this);
            recorderResumeButton.addActionListener(this);
            c2UserControlPanel.add(serverRow3);

            // Scenario realtimemultiple
            serverRow4 = new JPanel();
            JLabel coalitionSpeedupLabel = new JLabel("Scenario speedup:");
            JLabel coalitionEnterHere = new JLabel(" enter here to change:");
            serverRow4.add(coalitionSpeedupLabel);
            serverRow4.add(coalitionSpeedupValue);
            serverRow4.add(coalitionEnterHere);
            serverRow4.add(newCoalitionSpeedup);
            newCoalitionSpeedup.addActionListener(this);
            c2UserControlPanel.add(serverRow4);
            
            // Revert point
            serverRow5 = new JPanel();
            JLabel revertPoint = new JLabel("Save Revert Point");
            serverRow5.add(revertPoint);
            serverRow5.add(checkpointSaveButton);
            checkpointSaveButton.setSelected(false);
            checkpointSaveButton.addActionListener(this);
            c2UserControlPanel.add(serverRow5);
            serverRow6 = new JPanel();
            JLabel doRevert = new JLabel("Revert to Last Saved Point");
            serverRow6.add(doRevert);
            serverRow6.add(checkpointRestoreButton);
            checkpointRestoreButton.setSelected(false);
            checkpointRestoreButton.addActionListener(this);
            c2UserControlPanel.add(serverRow6);
            checkpointGroup = new ButtonGroup();
            checkpointGroup.add(checkpointSaveButton);
            checkpointGroup.add(checkpointRestoreButton);
            
        }// end if(runCoalitionControl.equals("1"))

        // hide all Radio buttons
        hideServerButtons();
        hidePlayerButtons();
        hideRecorderButtons();
        if(!playerState.getText().contains("UNKNOWN"))
            playerStartButton.setVisible(true);   

        // prepare for deployment;
        this.add(c2UserControlPanel);
        
    }// end class buildBox
    
    // set name and associated buttons for coaltion/server state
    void setCoalitionState(String newState){
        coalitionState = newState;
        serverCoalitionState.setText(
            "Simulation Coalition state: " + coalitionState);
        coalitionControlText.setText(
            "Simulation Coalition state: " + coalitionState);
        hideServerButtons();
        if(newState.equals("RUNNING")){
            serverStopButton.setVisible(true);
            serverPauseButton.setVisible(true);
        }
        else if(newState.equals("INITIALIZED")){
            serverResetButton.setVisible(true);
            serverStartButton.setVisible(true);
        }
        else if(newState.equals("PAUSED")){
            serverResumeButton.setVisible(true);
        }
        else if(newState.equals("UNINITIALIZED")){
            serverInitializeButton.setVisible(true);
        }
        else if(newState.equals("INITIALIZING")){
            serverResetButton.setVisible(true);
            serverShareButton.setVisible(true);
        }
        else if(newState.equals("STOPPED")){
            serverResetButton.setVisible(true);
        }
    }// end setCoalitionState()
    
    // check server response for state
    void checkResponse(String response){
        if(!response.contains("<sessionState>"))return;
        int startState = response.indexOf("<sessionState>") + 14;
        int endState = response.indexOf("</", startState);
        String sessionState = response.substring(startState,endState);
        if(!sessionState.equals(""))setCoalitionState(sessionState);
    }
    
    // supporting actions for JRadioButtons
    public void actionPerformed(ActionEvent buttonAction) {
        
        // player
        if(buttonAction.getSource() == playerStartButton){
            hidePlayerButtons();
            
            // get filename to play
            String playFilename = 
                inputTextPopup(
                    "Enter playback file path/name (blank for replay)");
            if(playFilename == null)playFilename = "";
            InitC2SIM initC2sim = new InitC2SIM();
            String playReply =
                initC2sim.pushC2simServerInput
                    ("STARTPLAY",serverPassword,playFilename,"");//StartPlayback
            playerState.setText(
                "Playback state: " + playbackResponse(playReply) + " ");
            playerStopButton.setVisible(true);
            playerPauseButton.setVisible(true);
        }
        else if(buttonAction.getSource() == playerStopButton){
            hidePlayerButtons();
            sendSystemMessage("STOPPLAY",false);//StopPlayback");
            initC2sim = new InitC2SIM();
            initC2sim.pushStatusPlayback();
            playerStartButton.setVisible(true);
        }
        else if(buttonAction.getSource() == playerPauseButton){
            hidePlayerButtons();
            sendSystemMessage("PAUSEPLAY",false);//PausePlayback");
            initC2sim = new InitC2SIM();
            initC2sim.pushStatusPlayback();
            playerResumeButton.setVisible(true);
        }
        else if(buttonAction.getSource() == playerResumeButton){
            hidePlayerButtons();
            sendSystemMessage("RESUMEPLAY",false);//ResumePlayback");
            initC2sim = new InitC2SIM();
            initC2sim.pushStatusPlayback();
            playerPauseButton.setVisible(true);
            playerStopButton.setVisible(true);
        }
        
        // recorder
        else if(buttonAction.getSource() == recorderStartButton){
            hideRecorderButtons();
            
            // recording always goes to replay.log
            sendSystemMessage("STARTREC",false);
            initC2sim = new InitC2SIM();
            initC2sim.pushStatusRecord();
            recorderStopButton.setVisible(true);
            recorderPauseButton.setVisible(true);
        }
        else if(buttonAction.getSource() == recorderStopButton){
            hideRecorderButtons();
            sendSystemMessage("STOPREC",false);
            initC2sim = new InitC2SIM();
            initC2sim.pushStatusRecord();
            recorderStartButton.setVisible(true);
        }
        else if(buttonAction.getSource() == recorderPauseButton){
            hideRecorderButtons();
            sendSystemMessage("PAUSEREC",false);
            initC2sim = new InitC2SIM();
            initC2sim.pushStatusRecord();
            recorderResumeButton.setVisible(true);
        }
        else if(buttonAction.getSource() == recorderResumeButton){
            hideRecorderButtons();
            sendSystemMessage("RESTARTREC",false);
            initC2sim = new InitC2SIM();
            initC2sim.pushStatusRecord();
            recorderPauseButton.setVisible(true);
            recorderStopButton.setVisible(true);
        }
        
        // server (setVisible of buttons done in setCoalitionState())
        else if(buttonAction.getSource() == serverStartButton){
            sendSystemMessage("START",true);//StartScenario
        }
        else if(buttonAction.getSource() == serverStopButton){
            sendSystemMessage("STOP",true);//StopScenario
        }
        else if(buttonAction.getSource() == serverPauseButton){
            sendSystemMessage("PAUSE",true);//PauseScenario
        }
        else if(buttonAction.getSource() == serverResumeButton){
            sendSystemMessage("RESUME",true);//ResumeScenario
        }
        else if(buttonAction.getSource() == serverShareButton){
            sendSystemMessage("SHARE",true);//ShareScenario
        }
        else if(buttonAction.getSource() == serverResetButton){
            sendSystemMessage("RESET",true);//ResetScenario
        }
        else if(buttonAction.getSource() == serverInitializeButton){
            sendSystemMessage("INITIALIZE",true);//SubmitInitialization
            
            // upload the initialization file
            InitC2SIM initC2sim = new InitC2SIM();
            initC2sim.submitInitFSC2SIM();
        }
        else if(buttonAction.getSource() == serverResetButton){
            sendSystemMessage("RESET",true);//ResetScenario
        }
        
        // speedup etc.
        else if(buttonAction.getSource() == newPlayerSpeedup) {
            try{
                playerSpeedup = Float.parseFloat(newPlayerSpeedup.getText());
            }
            catch(Exception e){
                showInfoPopup( 
                "cannot push speedup - format bad", 
                "C2 User Control Push Message");
            }
            newPlayerSpeedup.setText(" ");
            playbackTimescale = playerSpeedup.toString();
            initC2sim = new InitC2SIM();
            initC2sim.pushC2simServerInput("SETPLAYMULT",scenarioTimescale,"","");
            playerSpeedupValue.setText(playbackTimescale);
        }
        else if(buttonAction.getSource() == newCoalitionSpeedup) {
            try{
                coalitionSpeedup = Float.parseFloat(newCoalitionSpeedup.getText());
            }
            catch(Exception e){
                showInfoPopup( 
                "cannot push speedup - format bad", 
                "C2SIM Server Control Push Message");
            }
            newCoalitionSpeedup.setText(" ");
            scenarioTimescale = coalitionSpeedup.toString();
            initC2sim = new InitC2SIM();
            initC2sim.pushC2simServerInput("SETSIMMULT",scenarioTimescale,"","");
            coalitionSpeedupValue.setText(scenarioTimescale);
        }
        
        // checkpoint
        else if(buttonAction.getSource() == checkpointRestoreButton){
            String cprResponse = sendSystemMessage("CPRESTORE",true);//CheckpointRestore
            if(cprResponse.contains("cannot run"))
                checkpointGroup.clearSelection();
        }
        else if(buttonAction.getSource() == checkpointSaveButton){
            String cpsResponse = sendSystemMessage("CPSAVE",true);//CheckpointSave
            if(cpsResponse.contains("cannot run"))
                checkpointGroup.clearSelection();
        }
        
    }// end actionPerformed()
    
    // pull possible responses from reply
    String playbackResponse(String responseMessage){
        if(responseMessage.contains("NO_PLAYBACK_IN_PROGRESS"))
            return "NO_PLAYBACK_IN_PROGRESS";
        if(responseMessage.contains("PLAYBACK_RUNNING"))
            return "PLAYBACK_RUNNING";
        if(responseMessage.contains("PLAYBACK_PAUSED"))
            return "PLAYBACK_PAUSED";
        return "";
    }// end playbackResponse()
   
    // sends a SystemMessage
    String sendSystemMessage(String message, boolean showReply){     
        // open connection to REST server
        if(debugMode)bml.printDebug("system message:");
        if(submitterID.length() == 0) {
            showInfoPopup( 
                "cannot push C2SIM server control - submitter ID required", 
                "C2SIM Server Control Push Message");
            return "cannot push C2SIM server control - submitter ID required";
        }
        
        // start REST connection using performative for Initialize
        C2SIMClientREST_Lib c2simClient = ws.newRESTLib("INFORM");
        c2simClient.setHost(serverName);
        if(debugMode)bml.printDebug("C2SIM Order/Init Host:"+bml.serverName);
        c2simClient.setSubmitter(submitterID);
        if(bml.debugMode)bml.printDebug("C2SIM Order/Init Submitter:"+submitterID);
        c2simClient.setPath("C2SIMServer/c2sim");
        
        // get the password and check that it has content
        if(serverPassword.length() == 0){
            showInfoPopup( 
                "cannot push C2SIM Init - password required", 
                "C2SIM Server Control Push Message");
            return "cannot push C2SIM server control - password required";
        }

        // send the command
        String pushSendResponseString = "";
        try{
            pushSendResponseString = 
                c2simClient.c2simCommand(message,serverPassword,"","");
        } catch (C2SIMClientException bce) {
            showErrorPopup(
                "exception pushing C2SIMserver control:" +
                    bce.getMessage()+" cause:" + bce.getCauseMessage(), 
                "C2SIM Server Control Push Message");
            bml.printError("RESPONSE:" + pushSendResponseString);
            bce.printStackTrace();
        }

        // SHARE requires initialization
        if(message.equals("SHARE"))
            if(pushSendResponseString.contains(
                "no initialization data is present")){
                    showErrorPopup(
                        "no initialization data is loaded - cannot proceed",
                        "Initialization File Issue");
                    setCoalitionState("INITIALIZING");
                    InitC2SIM initC2sim = new InitC2SIM();
                    initC2sim.submitInitFSC2SIM();
                }
        
        // STARTPLAY requires valid filename
        if(message.equals("STARTPLAY")){
            if(pushSendResponseString.contains(
                "does not exist")){
                    showErrorPopup(
                        "can't locate playback file - cannot proceed",
                        "Playback File Issue");
                    sendSystemMessage("RESET",true);//StopScenario");
                }
        }
        
        // pick up RESET and set state to UNINITIALIZED
        if(pushSendResponseString.contains("RESET")){
            setCoalitionState("UNINITIALIZED");
        }
        else if(pushSendResponseString.contains("State set to ")){
            int startIndex = pushSendResponseString.indexOf("State set to ")+13;
            String setTo = pushSendResponseString.substring(startIndex).trim();
            setCoalitionState(setTo);
        }

        // display and return result
        if(debugMode)bml.printDebug("The C2SIM server control push result length : " +
                pushSendResponseString.length());
        System.out.println(pushSendResponseString);
        if(showReply)
            showInfoPopup(pushSendResponseString,"C2SIM Server response");
        return pushSendResponseString;
        
    }// end sendSystemMessage()
  
    /**
     * reads an XML file from the filesystem 
     * @param xmlUrl
     * @return file contents
     */
    public String readAnXmlFile(URL xmlUrl){
        return readAnXmlFile(xmlUrl.toString().substring(6));
    }
    public String readAnXmlFile(String xmlFilename) {
        // correct pathological path bug
        if(xmlFilename.charAt(0) != '.')
            if(xmlFilename.charAt(0) != '/')
                xmlFilename = "/" + xmlFilename;
        // read the file
        FileReader xmlFile;
        String xmlString = "";
        try{
          xmlFile=new FileReader(new File(xmlFilename));
          int charBuf; 
          while((charBuf=xmlFile.read())>0) {
            xmlString+=(char)charBuf;
          }
        }
        catch(FileNotFoundException fnfe){
          printError("file " + xmlFilename + " not found - returning empty string");
          return "";
        }
        catch(Exception e) {
          printError("Exception in reading XML file " + xmlFilename + ":"+e);
          e.printStackTrace();
          return "";
        }
        return xmlString;
  
    }// end readAnXmlFile()
  
    /**
     * starts the Server Subscriber thread
     * returns true if successful
     */
    public boolean startServerSubscribeThread(){
        
        // do nothing if STOMP is running
        if(getConnected())return true;
        if(debugMode)printDebug("Start Subscriber Thread");
        
        // start the subscriber thread
        try {
            subscriber = null;
            subscriber = new Subscriber();
        } catch (Exception e) {
            printError("Exception starting server subscribe thread:"+e);
            e.printStackTrace();
            return false;
        }
        threadSub = new Thread(subscriber);

        // Run the Subscriber in a separate thread
        if(debugMode)
            printDebug("Thread state "  + threadSub.getState().toString());
        threadSub.start();
        
        return true;
        
    }// end startServerSubscribeThread()
    
    /**
     * set STOMP connected state, then
     * enable/disable File menu items that push
     */
    void setConnected(boolean setPush) {
        stompIsConnected = setPush;
    }
    
    /**
     * returns connected state
     */
    boolean getConnected() {
        return stompIsConnected;
    }
    
    /**
     * checks a String for lack of ERROR returned on server command success 
     */
    boolean serverSuccess(String serverResponse){
        return !serverResponse.contains("ERROR");
    }
    
    /**
     * called by shutdownHook to shut down 
     * STOMP connection if it is running
     */
    private class shutdownStomp extends Thread {
        public void run() {
            if(subscriber != null) {
                if(getConnected()){
                    if(debugMode)printDebug("SHUTTING DOWN STOMP SUBSCRIPTION");
                    subscriber.stopSub();
                }
            }
        }
    }
    
    /**
     * called by shutdownHook to shut down 
     * Player if it is running
     */
    private class shutdownPlayer extends Thread {
        public void run() {
            if(!playerStatus.equals("STOPPED")) {
                if(debugMode)printDebug("SHUTTING DOWN PLAYER");
                if(getConnected())
                    sendSystemMessage("StopPlayback",false);
                
                // sleep long enough for Player to stop
                try{Thread.sleep(300);}catch(InterruptedException ie){}
            }
        }
    }
    
    /**
     * creates OK/Cancel dialog popup
     * returns true if user clicks OK
     */
    boolean okCancelPopup(String frameText, String message){
        
        int answer = JOptionPane.showConfirmDialog(
                    null,  
                    message, 
                    frameText,
                    JOptionPane.OK_CANCEL_OPTION);
        return (answer == JOptionPane.OK_OPTION);
        
    }// end oKCancelPopup
    
    /**
     * creates input dialog popup
     * returns new value 
     * returns zero if user selects cancel
     */
    String inputTimeMultPopup(String popupText){
        
        String answer = JOptionPane.showInputDialog(  
                    popupText, 
                    "0");
        return answer;
        
    }// end inputTimeMultPopup   
    
    /**
     * creates input dialog popup
     * returns new value 
     * returns zero if user selects cancel
     */
    String inputTextPopup(String popupText){
        
        String answer = JOptionPane.showInputDialog(  
                    popupText, 
                    "");
        return answer;
        
    }// end inputTextPopup   
	
    /**
     * Various Frame methods (no-op)
     */
    public void windowActivated(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconifieed(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowOpened(WindowEvent e) {}
    public void showHelp(HelpEvent event) {}
    public void itemStateChanged(ItemEvent arg0) {}

    public void windowClosed(WindowEvent e) {
            System.exit(0);
    }

    public void windowClosing(WindowEvent e) {
            System.exit(0);
    }

    /**
     * post a server status string 
     * @param serverState 
     */
    public void setServerStateLabel(String serverState) {

        // defend against serverState that accidentally includes whitepace or newline
        serverState.trim();
        if(serverState.endsWith("\n"))
            serverState = serverState.substring(0,serverState.length()-1);    
        
        // translate C2SIM standard SystemComandType to resulting server states
        if(serverState.equals("InitializationComplete"))serverState = "INITIALIZING";
        if(serverState.equals("PauseScenario"))serverState = "PAUSED";
        if(serverState.equals("ResetScenario"))serverState = "UNINITIALIZED";
        if(serverState.equals("ResumeScenario"))serverState = "RUNNING";
        if(serverState.equals("ShareScenario"))serverState = "INITIALIZED";
        if(serverState.equals("StartScenario"))serverState = "RUNNING";
        if(serverState.equals("StopScenario"))serverState = "UNINITIALIZED";
        if(serverState.equals("SubmitInititalization"))serverState = "INITIALIZING";
        
        // ignore SystemCommandss that do not affect server state
        if(serverState.equals("MagicMove"))return;
        if(serverState.equals("PausePlayback"))return;
        if(serverState.equals("PauseRecording"))return;
        if(serverState.equals("PlaybackRealtimeMultipleReport"))return;
        if(serverState.equals("PlaybackStatusReport"))return;
        if(serverState.equals("RecordingStatusReport"))return;
        if(serverState.equals("RefreshInit"))return;
        if(serverState.equals("RequestPlaybackRealtimeMultiple"))return;
        if(serverState.equals("RequestPlaybackStatus"))return;
        if(serverState.equals("RequestRecordingStatus"))return;
        if(serverState.equals("RequestSimulationRealtimeMultiple"))return;
        if(serverState.equals("ResumePlayback"))return;
        if(serverState.equals("ResumeRecording"))return;
        if(serverState.equals("SetPlaybackRealtimeMultiple"))return;
        if(serverState.equals("SetSimulationRealtimeMultiple"))return;
        if(serverState.equals("SimulationRealtimeMultipleReport"))return;
        if(serverState.equals("StartPlayback"))return;
        if(serverState.equals("StartRecording"))return;
        if(serverState.equals("StopPlayback"))return;
        if(serverState.equals("StopRecording"))return;
        if(serverState.equals("StopScenario"))return;

    }// end setServerStateLabel()
    
    /**
     * makes a string of '-' same length as its argument
     * (at least one dash)
     */
    String makeDashString(String template) {
        int dashLength = template.length();
        String dashString = "-"; 
        for(int i=1; i<dashLength; ++i)
           dashString += '-'; 
        return dashString;
    }
    
    /**
     * displays popup and prints error message 
     */
    public void showErrorPopup(String frameMessage, String errorMessage){
        
        printError(frameMessage+"\n"+errorMessage);
        JOptionPane.showMessageDialog(
            bml, 
            frameMessage, 
            errorMessage,
            JOptionPane.ERROR_MESSAGE);
        
    }// end showErrorPopup()
    
    /**
     * displays popup and prints info message 
     */
    public static void showInfoPopup(String frameMessage, String infoMessage){

        if(debugMode)printDebug("Dialog:"+frameMessage+"\n"+infoMessage);
        
        // display the dialog
        JOptionPane.showMessageDialog(
            bml, 
            frameMessage, 
            infoMessage,
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    // override to make WindowListener happy
    @Override
    public void windowDeiconified(WindowEvent e) {
        if(debugMode)printDebug("received unexpected call to WindowListner.windowDeiconified");
    }
    
    /*
    * obtains Java Date() and recorganizes to YYYY-MM-DD
    */
    HashMap<String,String> monthNum = null;
    String thisDate() {
        
        // make a HashMap to turn month code to a number
        // build it only once
        if(monthNum == null){
            monthNum = new HashMap<String,String>();
            monthNum.put("Jan","01");
            monthNum.put("Feb","02");
            monthNum.put("Mar","03");
            monthNum.put("Apr","04");
            monthNum.put("May","05");
            monthNum.put("Jun","06");
            monthNum.put("Jul","07");
            monthNum.put("Aug","08");
            monthNum.put("Sep","09");
            monthNum.put("Oct","10");
            monthNum.put("Nov","11");
            monthNum.put("Dec","12");
        }
        String date = (new Date()).toString();
        String month = monthNum.get(date.substring(4,7));
        return date.substring(24,28)+"-"+month+"-"+date.substring(8,10);
        
    }// end thisDate()

} // end of C2SIMcontrol Class
