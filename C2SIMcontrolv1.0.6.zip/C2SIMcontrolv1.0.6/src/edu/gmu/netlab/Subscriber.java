/*----------------------------------------------------------------*
|   Copyright 2009-2022 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 * package edu.gmu.c4i.sbmlsubscriber;
 */

package edu.gmu.netlab;

import com.jaxfront.core.util.URLHelper;
import java.io.File;
import javax.jms.*;
import java.util.*;
import java.util.HashMap;
import java.awt.Color;

// DOM and XPATH
import javax.xml.xpath.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Iterator;
import javax.swing.*;
import javax.swing.JFileChooser;

import edu.gmu.c4i.c2simclientlib2.C2SIMClientSTOMP_Lib;
import edu.gmu.c4i.c2simclientlib2.C2SIMClientException;
import edu.gmu.c4i.c2simclientlib2.C2SIMSTOMPMessage;
import edu.gmu.c4i.c2simclientlib2.C2SIMHeader;

import org.w3c.dom.*;
import static edu.gmu.netlab.C2SIMcontrol.bml;

/**
 * subscribes to STOMP server, reads STOMP message,
 * and if they are General Status Report posts them to map
 * 
 * @author dcorner
 * @author modified: mababneh
 * @since	3/1/2010
 * @param args the command line arguments
 */
public class Subscriber implements Runnable {
    
    static C2SIMcontrol bml = C2SIMcontrol.bml;
    public static String host = "HOSTNAME";
    static int count = 0;
    public static org.w3c.dom.Document listenerDocument;    // the C2SIM document
    public static boolean subscriberIsOn = false;
    public static TopicConnection conn = null;
    public static TopicSession session = null;
    private String rcvDocumentType = "";
    
    String subDocReportType = "";
    String subDocUnitID = "";
    String subDocGDCLat ="";
    String subDocGDCLon ="";
    
    int messageCount = 0;
    
    HashMap<String,ArrayList<String>> validSystemMessage;
    
    /**
     * Constructor
     */
    public Subscriber() throws Exception {
        // c2: can be executed by C2 User
        // server: requires coalition change auth
        validSystemMessage = new HashMap<String,ArrayList<String>>();
        putPolyMapV("c2","CheckpointRestore");
        putPolyMapV("c2","CheckpointSave");
        putPolyMapV("coalition","InitializationComplete");
        putPolyMapV("c2","MagicMove");
        putPolyMapV("c2","PausePlayback");
        putPolyMapV("c2","PauseRecording");
        putPolyMapV("c2","PauseScenario");
        putPolyMapV("c2","PlaybackRealtimeMultipleReport");
        putPolyMapV("c2","PlaybackStatusReport");
        putPolyMapV("c2","RecordingStatusReport");
        putPolyMapV("coalition","RefreshInit");
        putPolyMapV("c2","RequestPlaybackRealtimeMultiple");
        putPolyMapV("c2","RequestPlaybackStatus");
        putPolyMapV("c2","RequestRecordingStatus");
        putPolyMapV("c2","RequestSimulationRealtimeMultiple");
        putPolyMapV("coalition","ResetScenario");
        putPolyMapV("c2","ResumePlayback");
        putPolyMapV("c2","ResumeRecording");
        putPolyMapV("coalition","ResumeScenario");
        putPolyMapV("c2","SetPlaybackRealtimeMulltiple");
        putPolyMapV("c2","SetSimulationRealtimeMultiple");
        putPolyMapV("coalition","ShareScenario");
        putPolyMapV("c2","SimulationRealtimeMultipleReport");
        putPolyMapV("c2","StartPlayback");
        putPolyMapV("c2","StartRecording");
        putPolyMapV("coalition","StartScenario");
        putPolyMapV("c2","StopPlayback");
        putPolyMapV("c2","StopRecording");
        putPolyMapV("coalition","StopScenario");
        putPolyMapV("coalition","SubmitInitialization");
    }
    
    /**
     * Method to stop Subscriber
     */
    public void stopSub() {
    	subscriberIsOn = false;
        if(!bml.getConnected())return;
        bml.setConnected(false);
        if(bml.debugMode)bml.printDebug(
            "Subscriber is OFF - No messages will be accepted");
        try {
            stomp.disconnect();
        } 
        catch (C2SIMClientException bce) {
            bml.printError(
                "C2SIM Client Exception in disconnect: " + bce.getMessage());
        } 
    }// end stopSub()
    
    // "PolyMap" is a HashMap of ArrayLists
    // insert one PolyMap entry with key 'association'
    // This version is for HashMap NextStats
    void putPolyMapV(
        String association, String systemMessageType){
        // if PolyMap contains entry keyed to 'association',
        // add this systemMessageType to ArrayList for the association 
        ArrayList<String> tryList = validSystemMessage.get(association);
        if(tryList == null)tryList = new ArrayList<String>();
        if(validSystemMessage == null || validSystemMessage.isEmpty())
            tryList.add(systemMessageType);
        else
            tryList.add(systemMessageType);
        validSystemMessage.put(association,tryList);
    }// end putPolyMapV()
    
    ArrayList<String> getPolyMapV(String association) {
        
        ArrayList<String> result = validSystemMessage.get(association);
        return result;
    }// end getPolyMapV()
    
    /**
     * make a DOM Document from a String
     * @param is - input stream
     * @return
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException 
     */  
    public static org.w3c.dom.Document loadXmlFrom(java.io.InputStream is)
        throws org.xml.sax.SAXException, java.io.IOException
    {
        javax.xml.parsers.DocumentBuilderFactory factory =
            javax.xml.parsers.DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        javax.xml.parsers.DocumentBuilder builder = null;
        try
        {
            builder = factory.newDocumentBuilder();
        }
        catch (javax.xml.parsers.ParserConfigurationException ex) {}
        org.w3c.dom.Document doc = builder.parse(is);
        if(bml.debugMode)bml.printDebug("Document string" + doc.toString());
        is.close();
        return doc;
        
    }// end loadXmlFrom()
    
    /**
     *  Thread run() method to receive STOMP
     */
    C2SIMClientSTOMP_Lib stomp = null;
    public void run() {
      
        // setup for subscription
        host = bml.serverName;
        if(bml.debugMode)bml.printDebug("Begin Subscriber");
        if(bml.debugMode)bml.printDebug("Subscribe to : " +  host);
        if(bml.debugMode)bml.printDebug("making STOMP connection");
        String user, domain, hostSource;
        Document doc;

        // Create STOMP Client Object
        stomp = new C2SIMClientSTOMP_Lib();

        // Set STOMP parameters
        user = "C2SIMcontrol";
        domain = "ServerMessageBody";
        hostSource = bml.serverName;
        stomp.setHost(hostSource);
        stomp.setDestination("/topic/C2SIM");
        
        // echo parameters to log
        System.out.println("Subscribing STOMP client parameters:" +
            "Domain:" + domain + " STOMP host:" + hostSource);

        // Connect to the host
        C2SIMSTOMPMessage response = null;
        if(!bml.getConnected()) {
            System.out.println("Connecting to STOMP server at " + 
                stomp.getHost());
            try {
                response = stomp.connect();
                if (response.getMessageBody()==null) {
                    bml.printError(
                        "Failed to connect to STOMP host: " + 
                        hostSource + " - " + response.getMessageBody());
                    subscriberIsOn = false;
                    bml.setConnected(false);
                    return;
                }
            }
            catch (C2SIMClientException bce) {
                bml.printError("exception in connect to STOMP:" + bce.getCauseMessage());
                bml.showErrorPopup(
                    "connect timed out - restart C2SIMcontrol to try again",
                    "Server connection failed");
            }
        } 
        if(response == null)return;
        System.out.println("STOMP connect response received");
        bml.setConnected(true);
        subscriberIsOn = true;
        
        // send server status request
        InitC2SIM initC2SIM = new InitC2SIM();
        initC2SIM.pushStatusC2SIM();
        initC2SIM.pushStatusPlayback();
        if(bml.runCoalitionControl.equals("1"))
            initC2SIM.pushStatusRecord();

        // Start listening
        C2SIMSTOMPMessage message = null;
        try{
            while (subscriberIsOn)
            {
                // read message with STOMP blocking until next
                try {
                    message = stomp.getNext_Block();
                } catch(NullPointerException npe) {
                    if(bml.debugMode)bml.printDebug("STOMP GETNEXTBLOCK NULLPOINTER");
                    npe.printStackTrace();
                    subscriberIsOn = false;
                    bml.setConnected(false);
                    return;
                }

                // network read error - display popup and stop reading
                if(message == null){
                    try{Thread.sleep(1);}catch(InterruptedException ie){}
                    continue;
                }

                // extract parameters from header
                try {
                    String selectorDomain = message.getHeader("selectorDomain");
                    String protocol = message.getHeader("protocol");
                    String protocolVersion = message.getHeader("c2sim-version");
                    String submitter = message.getHeader("submitter");
                    String firstforwarder = message.getHeader("first-forwarder");
                    String messageSelector = message.getHeader("message-selector");
                    String messageBody = message.getMessageBody().trim();
                    if(bml.debugMode)
                        bml.printDebug(
                        "received STOMP protocol:" + protocol + 
                        " submitter:" + submitter +
                        " c2sim-version:" + protocolVersion +
                        " first-forwarder:" + firstforwarder +
                        " message-selector:" + messageSelector +
                        " messageBodyLength:" + messageBody.length());       
                    bml.threadSub.yield();
                    if(messageBody.length() == 0)continue;
                    interpretMessage(
                        messageBody, protocolVersion,messageSelector, submitter);
                } catch(NullPointerException npe) {
                    if(bml.debugMode)bml.printDebug("STOMP PARAMETERS NULLPOINTER");
                    npe.printStackTrace();
                    subscriberIsOn = false;
                    bml.setConnected(false);
                }
                
                // reset message and go back to wait loop
                message = null;
           
            }// end Subscriber while(subscriberIsOn)
        
        } catch(NullPointerException npe) {
          bml.printError("STOMP NULLPOINTER");
          npe.printStackTrace();
          subscriberIsOn = false;
          bml.setConnected(false);
        }
        catch(C2SIMClientException bce) {
            bml.printError("BMLClientException:" + bce.getMessage() +
                " cause:" + bce.getCauseMessage());
            bml.showErrorPopup( 
                "network read failed - disconnecting", 
                "Network Error Message");
            subscriberIsOn = false;
            bml.setConnected(false);
            bml.subscriberStatusLabel.setText("NO");
            bml.subscriberStatusLabel.setForeground(Color.RED);
        }
        catch(Exception e) {
          if(bml.debugMode)bml.printDebug("STOMP SUBSCRIBER EXCEPTION "+e.getMessage());
          e.printStackTrace();
          subscriberIsOn = false;
          bml.setConnected(false);
          bml.showInfoPopup("NETWORK DISCONNECT", "DISCONNECTED - RESTART CONTROL");
        } 
            
        // wait for messages to be delivered to the interpretMessage method
        while (subscriberIsOn) 
            try{Thread.sleep(100);}catch(InterruptedException ie){}
        
        // disconnect STOMP
        if(bml.getConnected()){
            try {
                stomp.disconnect();
            }
            catch(C2SIMClientException bce) {
                bml.printError("error disconnecting STOMP:" + bce.getCauseMessage());
            }
        }
        bml.setConnected(false);
        
    }// end run()
      
    /**
     * interprets MessageBody, saves data, and adds to map
     */
    public void interpretMessage(
        String messageBody, 
        String protocolVersion,
        String messageSelector,
        String submitter) {
        
        messageCount++;  

        // message could be server control, initialization, order or report
        // we care about only C2SIMMessage affecting server/recorder/player
        // note that we use the long name of new SISO C2SIM ontology here
        int index500 = messageBody.length();
        if(index500 > 500)index500 = 500;
        String first500 = messageBody.substring(0,index500);
        // for debugging, print the message
        //System.out.println("MESSAGEBODY PROTOCOL:" + protocolVersion + " SUBMITTER:" +
        //submitter + " SELECTOR:" + messageSelector + " FIRST500:\n" + messageBody);
       
        // server control messages
        String messageType = null;
        if(first500.contains(bml.c2simSystemMessageDomain)) {

           // get the state element value and post it
           int stateStartIndex = messageBody.indexOf("<SystemMessageBody>") + 20;
           int endStateStartIndex = messageBody.indexOf("<",stateStartIndex);
            int slashIndex = messageBody.indexOf(" />",stateStartIndex);
            if(slashIndex < 0)slashIndex = messageBody.indexOf(">",stateStartIndex);
            if(slashIndex < endStateStartIndex)endStateStartIndex = slashIndex;
            messageType = messageBody.substring(stateStartIndex,endStateStartIndex);
            
            setStateLabel(messageType);
            if(messageType.equals("RecordingStatusReport")){
                int startStatus = messageBody.indexOf("<RecordingStatusCode>")+21;
                int endStatus = messageBody.indexOf("</",startStatus);
                bml.recordStatus = messageBody.substring(startStatus,endStatus);
            }
        
            // coalition system messages
            // scan 'nextStates' for members of 'validSystemMessage'
            // with association "coalition" extracting coalition systemMessageCodes
            ArrayList<String> stateMessage = new ArrayList<String>();
            Iterator <Map.Entry<String,ArrayList<String>>> mapit =
                bml.nextStates.entrySet().iterator();
            ArrayList<String> testGetSys = getPolyMapV("coalition");

            // if the received message is a coalition message post state change
            if(testGetSys.contains(messageType)){
                setStateLabel(messageType); 
            
            }// end if(testGetSys.contains(messageType)

            // recording status system messages
            if(messageType.equals("RecordingStatusReport")){
                bml.recordState.setText("Recorder state: " + bml.recordStatus + " ");
                bml.hideRecorderButtons();
                if(bml.recordStatus.equals("RECORDING_IN_PROGRESS")){
                    bml.recorderStopButton.setVisible(true);
                    bml.recorderPauseButton.setVisible(true);
                }
                else if(bml.recordStatus.equals("NOT_RECORDING")){
                    bml.recorderStartButton.setVisible(true);
                }
                else if(bml.recordStatus.equals("RECORDING_PAUSED")){
                    bml.recorderResumeButton.setVisible(true);
                }
            }
            
            // playback status system messages
            if(messageType.equals("PlaybackStatusReport")){
                int startStatus = messageBody.indexOf("<PlaybackStatusCode>")+20;
                int endStatus = messageBody.indexOf("</",startStatus);
                bml.playerStatus = messageBody.substring(startStatus,endStatus);
                if(bml.playerStatus.equals("PLAYBACK_RUNNNING"))
                    bml.playerStatus = "PLAYBACK_RUNNING"; // correct for server bug
                bml.playerState.setText("Playback state: " + bml.playerStatus + " ");
                bml.hidePlayerButtons();
                if(bml.playerStatus.equals("PLAYBACK_RUNNING")){
                    bml.playerStopButton.setVisible(true);
                    bml.playerPauseButton.setVisible(true);
                }
                if(bml.playerStatus.equals("NO_PLAYBACK_IN_PROGRESS")){
                    bml.playerStartButton.setVisible(true);
                }
                if(bml.playerStatus.equals("PLAYBACK_PAUSED")){
                    bml.playerResumeButton.setVisible(true);
                }
            }
            
            // player system messages - set appropriate next state buttons
            if(messageType.equals("StartPlayback")){
                bml.hidePlayerButtons();
                bml.playerStopButton.setVisible(true);
                bml.playerPauseButton.setVisible(true);
            }
            else if(messageType.equals("ResumePlayback")){
                bml.hidePlayerButtons();
                bml.playerStopButton.setVisible(true);
                bml.playerPauseButton.setVisible(true);
            }
            else if(messageType.equals("StopPlayback")){
                bml.hidePlayerButtons();
                bml.playerStartButton.setVisible(true);
                bml.playerStartButton.setSelected(false);
            }
            else if(messageType.equals("PausePlayback")){
                bml.hidePlayerButtons();
                bml.playerResumeButton.setVisible(true);
            }
            
            // recorder system messages - sset appropriate next state buttons
            else if(messageType.equals("StartRecording")){
                bml.hideRecorderButtons();
                bml.recorderStopButton.setVisible(true);
                bml.recorderPauseButton.setVisible(true);
            }
            else if(messageType.equals("ResumeRecording")){
                bml.hideRecorderButtons();
                bml.recorderStopButton.setVisible(true);
                bml.recorderPauseButton.setVisible(true);
            }
            else if(messageType.equals("StopRecording")){
                bml.hideRecorderButtons();
                bml.recorderStartButton.setVisible(true);
            }
            else if(messageType.equals("PauseRecorder")){
                bml.hideRecorderButtons();
                bml.recorderResumeButton.setVisible(true);
            }
 
            // server system messages - set appropriate next state buttons
            else if(messageType.equals("StartScenario")){
                bml.hideServerButtons();
                bml.serverStopButton.setVisible(true);
                bml.serverPauseButton.setVisible(true);
            }
            else if(messageType.equals("StopScenario")){
                bml.hideServerButtons();
                bml.serverResetButton.setVisible(true);
            }
            else if(messageType.equals("SubmitInitialization")){
                bml.hideServerButtons();
                bml.serverResetButton.setVisible(true);
                bml.serverShareButton.setVisible(true);
            }
            else if(messageType.equals("PauseScenario")){
                bml.hideServerButtons();
                bml.serverResumeButton.setVisible(true);
            }
            else if(messageType.equals("ResetScenario")){
                bml.hideServerButtons();
                bml.serverInitializeButton.setVisible(true);
            }
            else if(messageType.equals("ShareScenario")){
                bml.hideServerButtons();
                bml.serverStartButton.setVisible(true);
                bml.serverResetButton.setVisible(true);
            }
            else if(messageType.equals("CheckpointSave")){
                bml.checkpointSaveButton.setSelected(true);
            }
            else if(messageType.equals("CheckpointRestore")){
               // bml.checkpointRestoreButton.setSelected(true);
            }
          
            // confirm server has the protocol version we use
            if(!bml.c2simProtocolOK(protocolVersion)){
                bml.printError("received wrong initialization protocol version:" + 
                    protocolVersion);
            }
            return;
            
        }// end first500.contains(bml.c2simSystemMessageDomain)..  
                
    } // end interpretMessage()
    
    void setStateLabel(String messageType){
        String labelType = "";
        if(messageType.equals("SubmitInitialization"))labelType = "INITIALIZING";
        if(messageType.equals("StopScenario"))labelType = "STOPPED";
        if(messageType.equals("StartScenario"))labelType = "RUNNING";
        if(messageType.equals("ShareScenario"))labelType = "INITIALIZED";
        if(messageType.equals("ResumeScenario"))labelType = "RUNNING";
        if(messageType.equals("ResetScenario"))labelType = "UNINITIALIZED";
        if(messageType.equals("PauseScenario"))labelType = "PAUSED";
        if(!labelType.equals(""))bml.setCoalitionState(labelType);
    }
    
    /**
     * Returns String YYYYMMDDHHMMSS.sss
     */
    public synchronized static String getTimeStamp() {
        Calendar now = Calendar.getInstance();        // Create a timestamp
        long i = System.currentTimeMillis() % 1000;
        String dttm = String.format("%04d/%02d/%02d %02d:%02d:%02d",
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH) + 1,
                now.get(Calendar.DATE),
                now.get(Calendar.HOUR_OF_DAY),
                now.get(Calendar.MINUTE),
                now.get(Calendar.SECOND),
                i);
        return dttm;
    }
    
} // end Subscriber Class
