/*----------------------------------------------------------------*
|   Copyright 2009-2024 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

// main function command-line arguments:
// 0. path-name of XML file holding C2SIMInitialization, in Initialization folder
// 1. path-name of neew C2SIMInitialization file produced by editing.
// 2. boolean true or false indicating whether <Entity> elements in
//    the C2SIMInitialization file are to be retained (optional; default: false)
// 3. boolean true to print debug data (optional; default: false)

package c2siminit;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import com.jaxfront.core.dom.DOMBuilder;
import com.jaxfront.core.dom.Document;
import com.jaxfront.core.help.HelpEvent;
import com.jaxfront.core.help.HelpListener;
import com.jaxfront.core.schema.ValidationException;
import com.jaxfront.core.ui.TypeVisualizerFactory;
import com.jaxfront.core.util.LicenseErrorException;
import com.jaxfront.core.util.URLHelper;
import com.jaxfront.core.util.io.BrowserControl;
import com.jaxfront.core.util.io.cache.XUICache;
import com.jaxfront.pdf.PDFGenerator;
import com.jaxfront.swing.ui.editor.EditorPanel;
import com.jaxfront.swing.ui.editor.ShowXMLDialog;
import com.jaxfront.core.dom.DocumentCreationException;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;
import java.util.*;
import java.io.*;
import java.io.FileReader;
import java.net.URL;
import java.awt.GridLayout;
import java.io.FileWriter;


/**
 *
 * @author jmarkpullen
 */
public class C2SIMinit extends JFrame 
    implements WindowListener, HelpListener, ItemListener, ActionListener
{
    // Version (compatible C2SIM_SMX_LOX_CWIX2024.xsd)
    public static String version = "1.0.4";
    
    // graphics
    private final static int WINDOW_HEIGHT = 200; // main window
    private final static int WINDOW_WIDTH = 400;  // main window
    private final int popupY = WINDOW_HEIGHT/2;
    private final int popupX = WINDOW_WIDTH/2;
    JButton oldNameButton;                        // edit object by name
    JButton oldUuidButton;                        // edit object by UUID
    JButton newObjectButton;                      // mak ea new object
    JButton saveAndQuitButton;                    // save C2SIM Init file and quit
    
    // global variables
    public static boolean initHasStarted = false;
    public static boolean retainEntities = false;
    public static boolean debugMode = false;
    public static String osName;
    public static boolean platformIsWindows;
    public static boolean platformIsUnix;
    public static String delimiter;
    static String c2simInitTemplateLocation;
    static String newC2simInitPathName;
    public static C2SIMinit init;
    static String xmlInitContents;
    static String xmlInitFilename;
    int xmlStartIndex;
    static String xmlPart1 = "";            // preamble and XML <AbstractObject>
    static String xmlObjectDefs = "";       // <ObjectDefinition>
    static String xmlObjectDefsPart1 = "";  // up to extracted entity
    static String xmlObjectDefsPart2 = "";  // after extracted entity
    static String currentEntity = "";       // current entity being edited
    static String xmlScenarioSetting = "";  // <ScenarioSetting>
    static String xmlSystemEntityLists = "";// <SystemEntityList>
    String initSchemaLocation;
    String initRoot;
    String xuiLocation;
    static String workingFolderLocation;
    static String jaxFrontContent = "";
    File xmlTempfile = null;
    String latestElementValue = "";
    String selectedName = "";
    static boolean thisEntityHasBeenExtracted = false;
    static ArrayList editedEntityNames = new ArrayList<String>();
    
    /**
     * Various Frame methods (no-op)
     */
    @Override public void windowActivated(WindowEvent e) {}
    @Override public void windowDeactivated(WindowEvent e) {}
    @Override public void windowDeiconified(WindowEvent e) {}
    @Override public void windowIconified(WindowEvent e) {}
    @Override public void windowOpened(WindowEvent e) {}
    @Override public void showHelp(HelpEvent event) {}
    @Override public void itemStateChanged(ItemEvent arg0) {}
    @Override public void windowClosed(WindowEvent e) {}
    @Override public void windowClosing(WindowEvent e) {
        if(initHasStarted) {
            printDebug("***C2SIMinit windowClosing");
            extractJaxContent();
            if(captureJaxContent(true))System.exit(9);
            System.exit(0);
        }
    }
    
    // constructor
    public C2SIMinit()
    { 
        super();
        
        // setup graphic control frame
        try {			
            // Add the title of the C2SIMinit Frame,
            // also specify sizes and display it
            setTitle("C2SIM Initialization Tool version " + version);
            
            setPreferredSize(new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT));
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Runtime.getRuntime().addShutdownHook(new shutdownInit());
        }
        catch (Exception e){
            printError("Exception in frame init:" + e.getMessage());
            e.printStackTrace();
        }
        
    }// end constructor
    
    /**
     * catch shutdown and save work
     */
    private class shutdownInit extends Thread
    {
        public shutdownInit()
        {
            if(initHasStarted){
                printDebug("***shutdownInit");
                if(captureJaxContent(true))System.exit(9);
                System.exit(0);
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Version " + version + 
            " of C2SIMInitialization XML file generator");
        
        // debug output
        if(args.length > 3)
            debugMode = args[3].equals("true");
        
        // parameter to retain entities
        if(args.length > 2) {
            retainEntities = args[2].equals("true");
            printDebug("retainEntities:"+retainEntities);
        }
        
        // template C2SIMInitialization file
        if(args.length > 0) {
            xmlInitFilename = args[0];
            printDebug("got init file name:" + xmlInitFilename);
        } else {
            printError("must have argument init file path+name");
            System.exit(1);
        } 
        
        // path-name of new file to be produced by this editor
        if(args.length > 1){
            newC2simInitPathName = args[1];
            printDebug("got output init file path-name:" + newC2simInitPathName);
        }
        
        // instantiate C2SIMinit
        init = new C2SIMinit();
        init.getParms();
        init.insertButtons();
      
        // get local directory
        c2simInitTemplateLocation = System.getProperty("user.dir") + "/Initialize";
        printDebug("C2SIMInitialize directory:"+c2simInitTemplateLocation);
        
        // read template file, and scan in XML segments        
        if(init.readTemplateFile())System.exit(2);
        if(init.ingestXmlSegments())System.exit(3);
        if(init.extractSims())System.exit(4);
        init.setVisible(true);
        initHasStarted = true;
    }// end main()
    
    /**
     * get runtime parameters
     */
    void getParms(){
        // get system type
        osName = System.getProperty("os.name");
        if(debugMode)printDebug("PLATFORM:"+osName);
        platformIsWindows = osName.contains("Windows");
        platformIsUnix = osName.contains("Linux");
        if(platformIsWindows) {
            if(debugMode)printDebug("OS Windows");
            delimiter = "\\";
        }
        else {
            if(debugMode)printDebug("OS Unix-like");
            delimiter = "/";
        } 
        // set look and feel
        try {
                // For Linux, etc., use GTK+ looks
                for (javax.swing.UIManager.LookAndFeelInfo info : 
                        javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("com.sun.java.swing.plaf.gtk.GTKLookAndFeel".equals(
                        info.getClassName())) {   
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    } 
                }	    	

            // set platform related
            workingFolderLocation = System.getProperty("user.dir");
            initSchemaLocation = workingFolderLocation + 
                "/Schema/C2SIM_SMX_LOX_CWIX2024.xsd";
            xuiLocation = workingFolderLocation + 
                "/Config/BMLC2GUIConfigView.xui";
            initRoot = "Entity";
        } catch (Exception e) {
            printError("Error setting look and feel: " + e.getMessage());
            return;
        }
    }// end getParms()
    
        /**
     * scans the segments of XML file into strings
     * returns true if expected endtags are not all found,
     * Used before any ENtity editing.
     * otherwise false
     */
    boolean ingestXmlSegments()
    {
        xmlStartIndex = 0;
        xmlPart1 = extractXml("</AbstractObject>"); 
        if(xmlPart1.length() == 0)return true;
        xmlObjectDefs = extractXml("</ObjectDefinitions>");
        if(xmlObjectDefs.length() == 0)return true;
        xmlScenarioSetting = extractXml("</ScenarioSetting>");
        if(xmlScenarioSetting.length() == 0)return true;
        xmlSystemEntityLists = extractXml("</SystemEntityList>");
        if(xmlSystemEntityLists.length() == 0)return true;
        return false;
    }// end canXmlSegments()
    
    /**
     * make buttons and add them to the frame
     * returns true if error found during the process
     */
    boolean insertButtons()
    {
        // instantiate the buttons
        oldNameButton = new JButton(
            "<html>edit existing<br>object initialization<br>by name</html>");
        oldNameButton.setSize(new Dimension(80,20));
        oldNameButton.addActionListener(init);
        oldUuidButton = new JButton(
            "<html>edit existing<br> object initialization<br>by UUID</html>");
        oldUuidButton.setSize(new Dimension(80,20));
        oldUuidButton.addActionListener(init);
        newObjectButton = new JButton(
            "<html>make a new<br>object initialization</html>");
        newObjectButton.setSize(new Dimension(80,20));
        newObjectButton.setOpaque(true);
        newObjectButton.setBackground(Color.WHITE);
        newObjectButton.addActionListener(init);
        saveAndQuitButton = new JButton(
            "<html>save C2SIMInitialization<br>and quit</html>");
        saveAndQuitButton.setSize(new Dimension(80,20));
        saveAndQuitButton.setOpaque(true);
        saveAndQuitButton.setBackground(Color.RED);
        if(platformIsWindows)
            saveAndQuitButton.setForeground(Color.WHITE);
        else saveAndQuitButton.setForeground(Color.RED);
        saveAndQuitButton.addActionListener(init);
 
        // insert the buttons in GridLayout
        try{
            // add buttons to frame
            init.add(oldNameButton);
            init.add(oldUuidButton);            
            init.add(newObjectButton);
            init.add(saveAndQuitButton);
            
            // add layout to frame and show
            init.setLayout(new GridLayout(2,2));
            init.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
            init.pack();
        }
        catch(Exception e){
            printDebug("exception in insertButtons:" + e.getMessage());
            return true;
        }
        return false;
    }// end insertButtons()
    
    /**
     * actions corresponding to buttons
     */
    // supporting actions for JRadioButtons
    @Override public void actionPerformed(ActionEvent buttonAction) {
        
        // edit existing by name
        if(buttonAction.getSource() == oldNameButton){
            editEntity("Name");
        }
        // edit existing by UUID
        else if(buttonAction.getSource() == oldUuidButton){
            editEntity("UUID");
        }
        // make new
        else if(buttonAction.getSource() == newObjectButton){
            makeNewEntity();
        }
        // save & quit
        else if(buttonAction.getSource() == saveAndQuitButton){
            saveInitFileAndQuit();
        }
    }//end actionPerformed()
    
    /**
     * editing existing <Entity> object selected by Name or UUID
     * returns true if problem, else false
     */
    static boolean editByNameRunning = false;
    static boolean editByUuidRunning = false;
    boolean editEntity(String tag){
        printDebug("****editEntity by:"+tag);
        
        // if another case is running ignore this button
        if(tag.equals("Name")){       
            if(newObjectRunning | editByUuidRunning)return false;
        } else {
            if(tag.equals("UUID")){
                if(newObjectRunning | editByNameRunning)return false;
            }
            else return true;
        }
        // editing existing Entity from xmlObjectDefs
        
        // we come through here when oldNameButton or oldUuidButton clicked
        
        // if the edit is already running, shut it down
        if(tag.equals("Name")){  // edit Entity chosen by Name    
            if(editByNameRunning){
                // reset button text
                oldNameButton.setText(
                    "<html>edit existing<b    r> object initialization<br>by Name</html>");
                oldNameButton.setBackground(Color.WHITE);
                oldNameButton.setForeground(Color.BLACK);
                editByNameRunning = false;
                
                // check whether result is to be saved
                if(keepEntityPopup("keep <Entity> now in JAXFront") == 
                    JOptionPane.YES_OPTION){
                    if(insertJaxIntoObjectDefs())return true;
                }
                        
                // clear out JaxFront to allow neew one
                releaseXUICache();
                if (editor != null)jaxPanel.remove(editor);
                jaxPanel.repaint();
                xuiCacheHash = 0;
                jaxFrontRunning = false;
                return false;
            }
            else 
            {
                // if not running, get user to select Entity to edit
                // also load it and split off other parts of xmlObjectDefs 
                if(chooseEntity(tag)){
                    printError("stopping due to problem in chooseEntity");
                    saveInitFileAndQuit();
                }
            }
        }
        else if(tag.equals("UUID")){  // edit Entity chosen by UUID       
            if(editByUuidRunning){
                // reset button text
                oldUuidButton.setText(
                    "<html>edit existing<br> object initialization<br>by UUID</html>");
                oldUuidButton.setBackground(Color.WHITE);
                oldUuidButton.setForeground(Color.BLACK);
                editByUuidRunning = false;
                                   
                // check whether result is to be saved
                if(keepEntityPopup("keep <Entity> now in JAXFront?") == 
                    JOptionPane.YES_OPTION){
                    if(insertJaxIntoObjectDefs())return true;
                }
                
                // clear out running JaxFront
                releaseXUICache();
                if (editor != null)jaxPanel.remove(editor);
                jaxPanel.repaint();
                xuiCacheHash = 0;
                jaxFrontRunning = false;
                return false;
            }
            else 
            {
                // if not running, get user to select Entity to edit
                // also load it and split off other parts of xmlObjectDefs 
                if(chooseEntity(tag)){
                    printError("stopping due to problem in chooseEntity");
                    saveInitFileAndQuit();
                }
                thisEntityHasBeenExtracted = false;
            }
        }
           
        // display the resulting Entity via JaxFront to be edited
        if(writeXmlFile(currentEntity))return true;
        if(startJax(xmlTempfile))return true;
        if(tag.equals("Name"))editByNameRunning = true;
        else if(tag.equals("UUID"))editByUuidRunning = true;
        
        // reassemble the ObjectDefnitions 
        // Part1 and Part2 are side-effects of chooseEntity()
        xmlObjectDefs = xmlObjectDefsPart1 + currentEntity + xmlObjectDefsPart2;
        if(tag.equals("Name")){
            oldNameButton.setText(
                "<html>finish object<br> initialization<br>by Name</html>");
            oldNameButton.setBackground(Color.GREEN);
            if(platformIsWindows)
                oldNameButton.setForeground(Color.WHITE);
            else oldNameButton.setForeground(Color.GREEN);
        }
        else { 
            if(tag.equals("UUID")){
                oldUuidButton.setText(
                    "<html>finish object<br> initialization<br>by UUID</html>");
                oldUuidButton.setBackground(Color.GREEN);
                if(platformIsWindows)
                    oldUuidButton.setForeground(Color.WHITE);
                else oldUuidButton.setForeground(Color.GREEN);
            }
        }
        return false;
    }// end editEntity()

    /**
     * make <Entity> object starting with blank JaxFront
     * returns true if problem, false otherwise
     */
    static boolean jaxFrontRunning = false;
    static boolean newObjectRunning = false;
    boolean makeNewEntity(){
        printDebug("****make new Entity");
        
        // edit only one Entity at a time
        if(editByNameRunning | editByUuidRunning)return false; 
        
        if(!jaxFrontRunning){// start editing process
            thisEntityHasBeenExtracted = false;
            startJax(null);
        }
        else {// stop editing this Entity
            // check whether result is to be kept
            if(keepEntityPopup("keep <Entity> now in JAXFront?") == 
                JOptionPane.YES_OPTION){
                // if yes, copy JaxFront xml new Entity and add to ObjectDefs
                int endLastEntity = xmlObjectDefs.lastIndexOf("</Entity>");
                xmlObjectDefsPart1 = xmlObjectDefs.substring(0,endLastEntity+9);
                xmlObjectDefsPart2 = xmlObjectDefs.substring(endLastEntity+9);
                if(!thisEntityHasBeenExtracted){
                    if(captureJaxContent(false))return true;
                    thisEntityHasBeenExtracted = true;
                }
            }
            
            // clear out running JaxFront 
            // ready for next new Entity
            releaseXUICache();
            if (editor != null)jaxPanel.remove(editor);
            jaxPanel.repaint();
            xuiCacheHash = 0;
        }

        // adjust button to show wcurrent state
        if(newObjectRunning){
            // clear the newObjectButton
            newObjectButton.setText(
                "<html>make a new<br>object initialization</html>");
            newObjectButton.setBackground(Color.WHITE);
            newObjectButton.setForeground(Color.BLACK);
            newObjectRunning = false;
        }
        else {
            newObjectButton.setText(
                "<html>finish new<br>object initialization</html>");
            newObjectButton.setBackground(Color.GREEN);
            if(platformIsWindows)
                newObjectButton.setForeground(Color.WHITE);
            else newObjectButton.setForeground(Color.GREEN);

            newObjectRunning = true;
        }
        return false;
    }// end makeNewEntity()
    
    /**
     * provide environment in which JAXFront editor to display
     * returns true if problem false otherwise
     */
    class jaxWindow extends JFrame implements WindowListener,
        HelpListener, ItemListener, ActionListener
    {
        @Override public void windowActivated(WindowEvent e) {}
        @Override public void windowDeactivated(WindowEvent e) {}
        @Override public void windowDeiconified(WindowEvent e) {}
        @Override public void windowIconified(WindowEvent e) {}
        @Override public void windowOpened(WindowEvent e) {}
        @Override public void showHelp(HelpEvent event) {}
        @Override public void itemStateChanged(ItemEvent arg0) {}
        @Override public void windowClosed(WindowEvent e) {System.exit(0);}
        @Override public void actionPerformed(ActionEvent e) {}
        @Override public void windowClosing(WindowEvent e) {
            if(C2SIMinit.captureJaxContent(true))System.exit(0);
            System.exit(0);
        }
        // constructor
        void jaxWindow(){
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
    }// end class jaxWindow
        
    // parameters for XML document
    static int xuiCacheHash = 0;
    static Document currentDom = null; 
    String root = null;        // Document Root node
    URL xsdUrl = null;         // String for Schema File
    URL xmlUrl = null;         // String for XML File / Document
    URL xuiUrl = null;         // String for JaxFront XUI file / Style view file
    URL tmpUrl = null;         // String for Temporary XML File / Document
    public String xmlReport = null;// holds latest report received from server 
    String currentXmlString = null;
    String currentLanguage = "en";    // English as default
    String loadedXml = "";
    String compareXml = "";
    EditorPanel editor;
    JPanel jaxPanel;
    JFrame jaxFrame;
    public boolean pushingJaxFront = false;
    
    /**
     * make a frame and panel to display JaxFront
     * this is used for both new objects and existing ones
     * @returnd true if problem, otherwise false
     */
    boolean startJax(File xmlfile){
        
        // make a frame and panel to display JaxFront
        jaxFrame = new jaxWindow(); 
        jaxFrame.setPreferredSize(new Dimension(1200,800));
        jaxFrame.pack();
        
        // setits size to 2/3 screen width x screen height
        Dimension screenSize = Toolkit. getDefaultToolkit().getScreenSize();
        jaxFrame.setSize(screenSize.width*2/3, screenSize.width);
        jaxFrame.setLocation(screenSize.width/3, 0);
        jaxFrame.setTitle("C2SIMinit editor version " + version +
            " schema CWIX2024");
        jaxFrame.addWindowListener(this);
        jaxFrame.setVisible(true);
        jaxPanel = new JPanel(new BorderLayout());
        JLabel jaxfrontLabel = new JLabel(
            " Forms generated by JAXFront free community license, " +
            " Xcentric Technology & Consulting");
        jaxFrame.add(jaxPanel);
        jaxPanel.setVisible(true);
        
        // setup JAX using initDOM
        releaseXUICache();
        xsdUrl = 
            URLHelper.getUserURL(initSchemaLocation);
        if(xmlfile == null)xmlUrl = null; //Empty XML
        else xmlUrl = URLHelper.getUserURL(xmlfile.getAbsolutePath());
        initRoot = "Entity";
        xuiUrl = 
            URLHelper.getUserURL(
                workingFolderLocation + "/Config/BMLC2GUIConfigView.xui");
        initDom(
            "default-context", 
            xsdUrl, 
            xmlUrl, 
            xuiUrl, 
            initRoot);
        jaxFrontRunning = true;
        return false;
    }// end startJax()
    
    /**
     * A wrapper around a commonly used DOMBuilder, 
     * which uses the params as-is.  Sets currentDom.
     * This is used to edit both new and existing objects.
     */
    public void initDom(
        String context, 
        URL url1, 
        URL url2, 
        URL url3, 
        String root){

        // check for changes in the XUI
        if(xuiCacheHash != 0){
            compareXml = getDomXmlLessJaxFront();
            if(loadedXml.compareTo(compareXml) != 0 && !pushingJaxFront) {
                int answer = JOptionPane.showConfirmDialog(
                    null,  
                    "About to overwrite changed data in form - load form anyhow?",
                    "Warning",
                    JOptionPane.OK_CANCEL_OPTION);
                if (answer != JOptionPane.OK_OPTION) {
                    return;
                }
            }
        }
        releaseXUICache();
        
        // build the DOM
        try {
            currentDom = 
                DOMBuilder.getInstance().build(context, url1, url2, url3, root);
            currentDom.getGlobalDefinition().setIsUsingButtonBar(false);
            currentDom.getGlobalDefinition().setIsUsingStatusBar(true);
            currentDom.getGlobalDefinition().setLanguage(currentLanguage);
            if (editor != null)editor.selectNode((com.jaxfront.core.type.Type) null);
            visualizeC2simDom();
        } catch (DocumentCreationException ex) {
            printError("DocumentCreationEXception in initDOM");
            ex.printStackTrace();	
        }
        
        // save XML and its hash as loaded  deb ugx
        xuiCacheHash = XUICache.getInstance().hashCode();
        loadedXml = getDomXmlLessJaxFront();

    }// end initDOM()
    
    /**
     * Generate the JaxFront Swing GUI from the 
     * DOM of the XML source of the C2SIM Document
     * This is used by initDOM to display Entity panel
     * for both new and existing Entity.
     */
    void visualizeC2simDom() { 
        
        // build JaxFront editor panel
        com.jaxfront.core.type.Type lastSelectedType = null;
        if (editor != null)if(editor.getSelectedTreeNode() != null)
            lastSelectedType = editor.getSelectedTreeNode().getType();
        TypeVisualizerFactory.getInstance().releaseCache(currentDom);	
        editor = new EditorPanel(currentDom.getRootType(), this);

        // configure JaxFront editor panel and insert it
        if (lastSelectedType != null)
            editor.selectNode(lastSelectedType);
        editor.setBorder(null);
        editor.addHelpListener(this);	
        JPanel validationErrorPanel = new JPanel(new BorderLayout());
        validationErrorPanel.setBorder(null);		
        editor.setTargetMessageTable(validationErrorPanel);		
        jaxPanel.add(editor, BorderLayout.CENTER);
        
    }// end visualizeBmlDom()
    
    /**
     * Pulls XML from JaxFront XUI and deletes the header
     */
    String getDomXmlLessJaxFront(){
        
        // get XML from the DOM
        if(currentDom == null)return null;
        String serialXml;
        try{
            serialXml = currentDom.serialize().toString();
        }
        catch(ValidationException ve){
            printError(
                "Failed to extract XML from JaxFront panel" +
                "Internal Error ");
            ve.printStackTrace();
            return "";
        }

        // remove the XML and JaxFront headers - each ends with '>'
        int headerEnd = serialXml.indexOf('>');
        if(headerEnd < 0)return"";
        serialXml = serialXml.substring(headerEnd+1);
        headerEnd = serialXml.indexOf('>');
        return serialXml.substring(headerEnd+1);
        
    }// end getXmlLessJaxFront()
    
    /**
     * put XML string into xmlTempfile
     * This is used to present new Entity object for editing
     * returns true if problem, otherwise false
     */
    boolean writeXmlFile(String xml){
        try{
            if(xmlTempfile != null)xmlTempfile.delete();
            xmlTempfile = File.createTempFile("xml","TempXML");
            FileWriter tempFile = new FileWriter(xmlTempfile);
            tempFile.write(xml);
            tempFile.close();
        }
        catch(IOException iox){
            printError("IOException in writeXmlFile:" +iox.getMessage());
            return true;
        }
        return false;
    }
            
    /**
     * frees JaxFront cache to be used for new Entity
     */
    public void releaseXUICache() {
        XUICache.getInstance().releaseCache();
    }// end releaseXUIcache
    
    /**
     * writing new C2SIMInitialization file and quitting
     * also offer to delete Entity from objectDefs
     * This responds to the Save and QUit button.
     */
    void saveInitFileAndQuit(){
        printDebug("***SaveInitAndQuit");   
        // if JAXFront is running, save its product to ObjectDefinitions
        if(captureJaxContent(false))System.exit(8);
        
        // offer to delete Entities
        while(yesNoPopup("delete some <Entity>?") == JOptionPane.YES_OPTION){
            // use File Chooser to offer user selection
            File tempName, tempDir, tempEntityDir = null;
            String xmlTag = "<Name>";
            try{
                tempName = File.createTempFile("delete-","entity");
                tempDir = tempName.getParentFile();
                tempEntityDir = new File(tempDir.getAbsolutePath()+"/Entities");
                tempEntityDir.mkdir();
            }
            catch(Exception e){
                printError("temp file creation error in displayObjectCooser" +
                    e.getMessage());
                System.exit(13);
            }
            JFileChooser nameFc = new JFileChooser(tempEntityDir);
            nameFc.setMultiSelectionEnabled(false);
            nameFc.removeChoosableFileFilter(nameFc.getAcceptAllFileFilter());
            nameFc.setFileFilter(
                new FileNameExtensionFilter("entity delete pseudo files", "entity"));
        
            // extract all <Entity> by xmlTags into the Chooser
            int entityStart=0,entityIndex=0, entityEnd=0, nameIndex=0, nameEnd=0;
            while(true){
                // find next Entity Tag
                entityIndex = xmlObjectDefs.indexOf("<Entity>",entityStart);
                if(entityIndex < 0)break;
                entityEnd = xmlObjectDefs.indexOf("</Entity>",entityIndex);
                if(entityEnd < 0){
                    printError("missing </Entity> in XML");
                    System.exit(13);
                }
                nameIndex = xmlObjectDefs.indexOf(xmlTag,entityIndex);
                if(nameIndex < 0){
                    showInfoPopup(true,
                    "INCORRECT XML", "Missing " + xmlTag + " in <Entity>");
                    System.exit(13);
                }
                String endTag = "</Name>";
                if(xmlTag.equals("<UUID>"))endTag = "</UUID>";
                nameEnd = xmlObjectDefs.indexOf(endTag,nameIndex);
                if(nameEnd < 0 || nameEnd > entityEnd){
                    showInfoPopup(true,
                    "INCORRECT XML", "Missing " + endTag + " in <Entity>");
                    System.exit(13);
                }

                // name a dummy File by that name so JFileChooser can be used
                latestElementValue = xmlObjectDefs.substring(nameIndex+6,nameEnd)+".entity";
                File dummyEntityNameFile = new File(tempEntityDir,latestElementValue);

                // write the name in the file
                try{
                    FileWriter entityFile = new FileWriter(dummyEntityNameFile);
                    entityFile.write(latestElementValue);
                    entityFile.close();
                }
                catch(IOException ioe){
                    printDebug("IOException in chooseEntity() extracting " +
                       latestElementValue + ":"+ioe.getMessage());
                    System.exit(13);
                }

                // go to next <Entity>
                entityStart = entityEnd+9;
            }// end while(true)
        
            nameFc.setDialogTitle("click on Entity name to delete");
            int result = nameFc.showOpenDialog(this);
            if (result == JFileChooser.CANCEL_OPTION) {
                deleteFiles(tempEntityDir);
                return;
            }
            File selectedDummy = nameFc.getSelectedFile();
            if(selectedDummy == null){
                printError("Can't find selected Entity object in displayObjecChooser");
                System.exit(13);
            }
            // extract Entity name/uuid from chosen File
            selectedName =  selectedDummy.getName();
            selectedName = selectedName.substring(0,selectedName.length()-7);

            // copy the chosen Entity to currentEntity
            // find next Entity with prescribed Tag
            entityStart = 0;
            while(true){
                entityIndex = xmlObjectDefs.indexOf("<Entity>",entityStart);
                if(entityIndex < 0){
                    printError("Missed <Entity> in chooseEniity()");
                    System.exit(13);
                }
                entityEnd = xmlObjectDefs.indexOf("</Entity>",entityIndex);
                if(entityEnd < 0){
                    showInfoPopup(true,"INCORRECT XML", 
                        "Missing </Entity> XML");
                    System.exit(13);
                }
                // look for the sought tag Name
                nameIndex = xmlObjectDefs.indexOf(xmlTag,entityIndex);
                if(nameIndex < 0){
                    showInfoPopup(true,"INCORRECT XML", "Missing " + xmlTag + " in <Entity>");
                    System.exit(13);
                }
                nameEnd = xmlObjectDefs.indexOf("</Name>",nameIndex);
                if(nameEnd < 0 || nameEnd > entityEnd){
                    showInfoPopup(true,"INCORRECT XML", 
                        "Missing \"</Name>\" in <Entity>");
                    System.exit(13);
                }
                if(xmlObjectDefs.substring(nameIndex+6,nameEnd).equals(selectedName))break;

                // go to next <Entity>
                entityStart = entityEnd + 9;
            }
            xmlObjectDefs = 
                xmlObjectDefs.substring(0,entityIndex) + xmlObjectDefs.substring(entityEnd+9);
            
            // delete the files used for Chooser
            String[]entries = tempEntityDir.list();
            for(String s: entries){
                File currentFile = new File(tempEntityDir.getPath(),s);
                currentFile.delete();
            }
        }//end while(yesNoPopup...
         
        // save file and quit
        writeInitFile();
        System.exit(0);
    }// end saveInitFileAndQuit()
    
    /**
     * writes a C2SIMInitialization file
     * returns true if problem, otherwise false
     */
    static String saveXml;
    static boolean writeInitFile(){
        printDebug("***writeInitFile "+newC2simInitPathName);
        try {
            if(saveFilePopup("save revised C2SIMInitialization?") != 
                    JOptionPane.YES_OPTION)
                return(true);
            
            // find and delete the previous version of the file
            File initFile = new File(newC2simInitPathName);
            if(initFile.exists()){
                initFile.delete();
                initFile = new File(newC2simInitPathName);
            }
      
            // delete from xmlObjectDefs any Entity not in editedEntities
            int startEntity = 0;
            if(!retainEntities)
            while(true){
                // locate the Name in Entity
                int entityIndex = xmlObjectDefs.indexOf("<Entity>",startEntity);
                if(entityIndex < 0)break;
                int entityEnd = xmlObjectDefs.indexOf("</Entity>",entityIndex);
                if(entityEnd < 0){
                    printError("</Entity> not found where expected in writeInitFile");
                    return true;
                }
                int nameIndex = xmlObjectDefs.indexOf("<Name>",entityIndex);
                if(nameIndex < 0){
                    printError("<Name> not found where expected in writeInitFile");
                    return true;
                }
                int nameEnd = xmlObjectDefs.indexOf("</Name>",nameIndex);
                if(entityEnd < 0){
                    printError("</Name> not found where expected in writeInitFile");
                    return true;
                }
                         
                // if Named Entity has not been edited, delete that entity
                // notice that this shifts the starting point for next <Entity
                String name = xmlObjectDefs.substring(nameIndex+6,nameEnd);   
                if(!editedEntityNames.contains(name)){
                    xmlObjectDefs = xmlObjectDefs.substring(0,entityIndex) +
                        xmlObjectDefs.substring(entityEnd+9);
                   printDebug("*** not retaining " + name);
                   startEntity = entityEnd + 9 - (entityEnd+9-entityIndex);
                }
                else{
                    printDebug("*** retaining " + name);
                    startEntity = entityEnd + 9;
                }
            }// end while(true)
           
            // build new init file contents
            saveXml = xmlPart1.trim() + xmlObjectDefs.trim() + 
                xmlScenarioSetting.trim() + xmlSystemEntityLists.trim() +
                "</C2SIMInitializationBody></MessageBody>";
             
            // write a new opy of the file
            FileWriter initWrite = new FileWriter(initFile);
            initWrite.write(saveXml);
            initWrite.close();
        }
        catch(IOException iox){
            printError("IOException in writeInitFile:" +iox.getMessage());
            return true;
        }
        return false;
    }// end writeInitFile()
    
    /**
     * if JAXFront is running, add its product to ObjectDefinitions
     * Used any time there is a shutdown.
     * saveFile is for shutdown when init file needs saved
     * returns true if problem, otherwise false
     */
    static boolean captureJaxContent(boolean saveFile){
        printDebug("***captureJaxContent");
        // if JAXFront is running, save its product to ObjectDefinitions
        if(!jaxFrontRunning)return false;
        if(!thisEntityHasBeenExtracted){
            extractJaxContent();
            if(checkUuid())printErrorAndQuit("UUID",9);
            if(checkSystemLists())printErrorAndQuit("SYSTEM LISTS",14);
            if(insertJaxIntoObjectDefs())
                printErrorAndQuit("INSERT TO OBJ DEFS",6);
            thisEntityHasBeenExtracted = true;
        }                
        // option to write a new C2SIMInitialization file
        if(saveFile){if(writeInitFile())System.exit(10);}
        return false;
    }// end captureJaxContent()
    
    /**
     * print an error message an pass parameter to System.exit()
     * 
     */
    static void printErrorAndQuit(String cause, int exitCode){
        printError("fatal error in captureJaxContent:" + cause);
        System.exit(exitCode);
    }  // end printErrorAndQUit()
    
    /**
     * Pulls out the current Entity in JaxFront to jaxFrontContent String
     * returns true if problem, otherwise false
     */
    static boolean extractJaxContent(){
        printDebug("***extractJaxContent");
        // serialize the current Dom
        try{
            jaxFrontContent = currentDom.serialize().toString();
        }
        catch(ValidationException v){
            printError("*** Validation Exception in extractJaxFront()");
            return true;
        }
        
        // reset cache hash to show data has been saved
        xuiCacheHash = XUICache.getInstance().hashCode();
        return false;
        
    }// end extractJaxFrontContent()
    
    /**
     * check jaxFrontContent for UUID;
     * if none, generate and insert UUID
     * and inform user via popup
     * Used for new Entity object only
     * Returns true if problem, otherwise false
     */
    static boolean checkUuid(){
        printDebug("***checkUuid");
        // if UUID is present no need to make one
        if(jaxFrontContent.indexOf("<UUID>") > 0)return false;
        int nameStart = jaxFrontContent.indexOf("<Name>");
        if(nameStart < 0){
            showInfoPopup(true,"INCORRECT XML", 
                "JaxFront <Entity> mssing <Name>");
            return true;
        }
 
        // make a UUID and insert after </Name>
        String newUuid = UUID.randomUUID().toString();
        int voidUuid = jaxFrontContent.indexOf("<UUID/>");
        if(voidUuid < 0){
            showInfoPopup(true,"INCORRECT XML","missing <UUID/>");
            return true;
        }
        showInfoPopup(true,"MISSING UUID",
            "adding random UUID to saved <Entity>");
        String firstPart = jaxFrontContent.substring(0,voidUuid);
        String lastPart = jaxFrontContent.substring(voidUuid+7);
        jaxFrontContent = firstPart + "<UUID>" + newUuid + "</UUID>" + lastPart;
        return false;
    }// end checkUuid()
    
    /**
     * check UUID in currentEntity against SystemEntoty lists
     * if there; inform user; if not there, ask user for System
     * and put it under that one
     * returns true if problem, otherwise false
     */
     static boolean checkSystemLists(){
         printDebug("****checkSystemLists");
         // get UUID from jaxFrontContent (if missing, error)
         int uuidIndex = jaxFrontContent.indexOf("<UUID>");
         if(uuidIndex < 0){
            showInfoPopup(true,"XML ERROR IN SYSTEM ENTITY LIST",
                "can't find <UUID> in existing JaxFront content");
            return  true;
        }
         int uuidEnd = jaxFrontContent.indexOf("</UUID>",uuidIndex);
         if(uuidIndex < 0){
            showInfoPopup(true,"XML ERROR IN SYSTEM ENTITY LIST",
                "can't find </UUID> in existing JaxFront content");
            return  true;
         }
         String uuid = jaxFrontContent.substring(uuidIndex+6,uuidEnd);
         
         // look for the UUID In systemEntityLists polyMap
         String systemName = systemMapPlus.get(uuid);
         
         // if there, inform user and return
         if(systemName != null){
             showInfoPopup(true,"SYSTEM WITH UUID EXISTS",
                "Entity UUID:" + uuid + " exists in SystemName:" + systemName +
                " - to change system assign a new UUID");
             return false;
         }
         
         // ask user for SystemName to add UUID; in not valid error
         boolean foundSysName = false;
         String newSystemName = "";
         while(!foundSysName){
            newSystemName = inputTextPopup(
                "enter SystemName to associate with this Entity");
            if(newSystemName.length() == 0)return true;
         
            // add the UUID to xmlSystemEntityLists
            if(getPolyMap(newSystemName) == null){
                showInfoPopup(true,"CAN'T FIND THAT SYSTEM NAME",
            "SystemName:" + newSystemName + " not found in existing C2SIM initialization; "+
                    "please try again (just return to quit)");
                if(newSystemName.length() == 0)System.exit(15);
            }
            else foundSysName = true;
         }

         // add the new UUID to the SystemEntityList for the new SystemName
         // and also to the PolyMap for that SystemName
         int entityListStart = 0, systemNameIndex = 0;
         String testSystemName = "";
         while(true){
             // find next SystemEntityList
            int entityListIndex = xmlSystemEntityLists.indexOf("<SystemEntityList>");
            if(entityListIndex < 0){
                showInfoPopup(true,"XML ERROR IN SYSTEM ENTITY LIST",
                    "can't find <SystemEntityList> in existing C2SIM initialization");
                return  true;
            }
            int entityListEnd = xmlSystemEntityLists.indexOf("</SystemEntityList>",
                entityListIndex);
            if(entityListEnd < 0){
                showInfoPopup(true,"XML ERROR IN SYSTEM ENTITY LIST",
                    "can't find </SystemEntityList> in existing C2SIM initialization");
                return  true;
            }

            // find the SystemName in this list
            systemNameIndex = xmlSystemEntityLists.indexOf("<SystemName>",entityListIndex);
            if(systemNameIndex < 0){
                showInfoPopup(true,"XML ERROR IN SYSTEM ENTITY LIST",
                    "can't find <SystemName> in existing C2SIM initialization");
                return  true;
            }
            int systemNameEnd = xmlSystemEntityLists.indexOf("</SystemName>",
                systemNameIndex);
            if(systemNameEnd < 0 | systemNameEnd > entityListEnd){
                showInfoPopup(true,"XML ERROR IN SYSTEM ENTITY LIST",
                    "can't find </SystemName> in existing C2SIM initialization");
                return  true;
            }
            testSystemName = 
                xmlSystemEntityLists.substring(systemNameIndex+12,systemNameEnd);          
            if(testSystemName.equals(newSystemName))break;
            // go to next SystemEntityList
            entityListStart = entityListEnd + 19;
         }// end while(true)
         if(!testSystemName.equals(newSystemName)){
            showInfoPopup(true,"INTERNAL ERROR IN SYSTEM ENTITY LIST",
                "can't find known <SystemName> in existing C2SIM initialization");
            return  true;
         }
         // add new UUID to the end of SystemEntityList selected
         xmlSystemEntityLists = 
            xmlSystemEntityLists.substring(0,systemNameIndex) +
            "<ActorReference>" + uuid + "</ActorReference>" +
            xmlSystemEntityLists.substring(systemNameIndex);
       
         // add it to thr PolyMap also
         putPolyMapPlus(newSystemName, uuid);
         return false;
     }// end checkSystemLists()
    
    /**
     * insert an Entity into ObjectDefs
     * used for both new and existing Entity
     * relies on xmlObjectDefsPart1 and xmlObjectDefsPart2
     * having been set in chooseEntity()
     * returns true if problem, otherwise false
     */
    static boolean insertJaxIntoObjectDefs(){
        printDebug("****copy JAXfront to ObjectDefs");
        
        // assemble new xmlObjectDefs including Entity from jaxFrontContent
        extractJaxContent();
        int actorIndex = jaxFrontContent.indexOf("<ActorEntity>");
        if(actorIndex < 0){
            showInfoPopup(true,"INCORRECT XML",
                "can't find <ActorEntity> in jAXFront content");
            return true;
        }
        int endEntity = jaxFrontContent.indexOf("</Entity>");
        if(actorIndex < 0){
            printError("Internal error - </Actor> missing");
            return true;
        }
        xmlObjectDefs = xmlObjectDefsPart1 + "<Entity>" + 
            jaxFrontContent.substring(actorIndex) +
            xmlObjectDefsPart2;
        if(addToEditedEntities(jaxFrontContent))return true;
        return false;
    }// end insertJaxIntoObjectsDefs()
    
    /**
     * extract Name from edited Entity and store in HashM<ap
     * 
     */
    static boolean addToEditedEntities(String xmlEntity){
        // extract entitiy Nmme
        int nameIndex = xmlEntity.indexOf("<Name>");
        if(nameIndex < 0){
            printError("can't find <Name> in Entity");
            return true;
        }
        int nameEnd = xmlEntity.indexOf("</Name>");
        if(nameIndex < 0){
            printError("can't find <Name> in Entity");
            return true;
        }
        String name = xmlEntity.substring(nameIndex+6,nameEnd);
        editedEntityNames.add(name);
        printDebug("***add to editedEntities:"+name);
        return false;
    }// end addToEditedEntities(()
    
    /**
     * display all Entity object names or UUIDs (per tag) and 
     * accept click on one; move that chosen Entity to currentEntity
     * returns true if problem found, false otherwise
     */
    boolean chooseEntity(String tag){
        String xmlTag = "<" + tag + ">";
        printDebug("***chooseEntity:"+xmlTag);
        // use File Chooser to offer user selection
        File tempName, tempDir, tempEntityDir;
        try{
            tempName = File.createTempFile(tag+"-","entity");
            tempDir = tempName.getParentFile();
            tempEntityDir = new File(tempDir.getAbsolutePath()+"/Entities");
            tempEntityDir.mkdir();
        }
        catch(Exception e){
            printError("temp file creation error in displayObjectCooser" +
                e.getMessage());
            return true;
        }
        JFileChooser nameFc = new JFileChooser(tempEntityDir);
        nameFc.setMultiSelectionEnabled(false);
        nameFc.removeChoosableFileFilter(nameFc.getAcceptAllFileFilter());
        nameFc.setFileFilter(
            new FileNameExtensionFilter("entity "+tag+" pseudo files", "entity"));
        
        // extract all <Entity> by xmlTags into the Chooser
        int entityStart=0,entityIndex=0, entityEnd=0, nameIndex=0, nameEnd=0;
        while(true){
            // find next Entity Tag
            entityIndex = xmlObjectDefs.indexOf("<Entity>",entityStart);
            if(entityIndex < 0)break;
            entityEnd = xmlObjectDefs.indexOf("</Entity>",entityIndex);
            if(entityEnd < 0){
                printError("missing </Entity> in XML");
                return true;
            }
            nameIndex = xmlObjectDefs.indexOf(xmlTag,entityIndex);
            if(nameIndex < 0){
                showInfoPopup(true,"INCORRECT XML", 
                    "Missing " + xmlTag + " in <Entity>");
                return true;
            }
            String endTag = "</Name>";
            if(xmlTag.equals("<UUID>"))endTag = "</UUID>";
            nameEnd = xmlObjectDefs.indexOf(endTag,nameIndex);
            if(nameEnd < 0 || nameEnd > entityEnd){
                showInfoPopup(true,"INCORRECT XML", 
                    "Missing " + endTag + " in <Entity>");
                return true;
            }
 
            // name a dummy File by that name so JFileChooser can be used
            latestElementValue = xmlObjectDefs.substring(nameIndex+6,nameEnd)+".entity";
            String cleanLatest = latestElementValue.replace('/','^');
            File dummyEntityNameFile = new File(tempEntityDir,cleanLatest);
            
            // write the name in the file
            try{
                FileWriter entityFile = new FileWriter(dummyEntityNameFile);
                entityFile.write(cleanLatest);
                entityFile.close();
            }
            catch(IOException ioe){
                printDebug("IOException in chooseEntity() extracting " +
                    cleanLatest + ":"+ioe.getMessage());
                return true;
            }
            
            // go to next <Entity>
            entityStart = entityEnd+9;
        }// end while(true)
        
        nameFc.setDialogTitle("click on Entity identifier");
        int result = nameFc.showOpenDialog(this);
        if (result == JFileChooser.CANCEL_OPTION) {
            deleteFiles(tempEntityDir);
            return true;
        }
        File selectedDummy = nameFc.getSelectedFile();
        if(selectedDummy == null){
            printError("Can't find selected Entity object in displayObjectChooser");
            deleteFiles(tempEntityDir);
            return true;
        }
        // extract Entity name/uuid from chosen File
        selectedName =  selectedDummy.getName();
        selectedName = selectedName.substring(0,selectedName.length()-7);
        selectedName = selectedName.replace('^','/');
        
        // copy the chosen Entity to currentEntity
        // find next Entity with prescribed Tag
        entityStart = 0;
        while(true){
            entityIndex = xmlObjectDefs.indexOf("<Entity>",entityStart);
            if(entityIndex < 0){
                printError("Missed <Entity> in chooseEniity() for " +
                    selectedName);
                deleteFiles(tempEntityDir);
                return true;
            }
            entityEnd = xmlObjectDefs.indexOf("</Entity>",entityIndex);
            if(entityEnd < 0){
                showInfoPopup(true,"INCORRECT XML", "Missing </Entity> XML for" +
                    selectedName);
                deleteFiles(tempEntityDir);
                return true;
            }
            // look for the sought tag (Name or UUID)
            nameIndex = xmlObjectDefs.indexOf(xmlTag,entityIndex);
            if(nameIndex < 0){
                showInfoPopup(true,"INCORRECT XML", "Missing " + 
                    xmlTag + " in <Entity>");
                deleteFiles(tempEntityDir);
                return true;
            }
            String endTag = "</Name>";
            if(xmlTag.equals("<UUID>"))endTag = "</UUID>";
            nameEnd = xmlObjectDefs.indexOf(endTag,nameIndex);
            if(nameEnd < 0 || nameEnd > entityEnd){
                showInfoPopup(true,"INCORRECT XML", "Missing " + 
                    endTag + " in <Entity>");
                deleteFiles(tempEntityDir);
                return true;
            }
            if(xmlObjectDefs.substring(nameIndex+6,nameEnd).equals(selectedName))break;

            // go to next <Entity>
            entityStart = entityEnd + 9;
        }
        latestElementValue = xmlObjectDefs.substring(nameIndex,nameEnd);
        currentEntity = xmlObjectDefs.substring(entityIndex,entityEnd+9);
        
        // split off parts of xmlObjectDefs before and after this Entity
        xmlObjectDefsPart1 = xmlObjectDefs.substring(0, entityIndex);
        xmlObjectDefsPart2 = xmlObjectDefs.substring(entityEnd+9);
      
        // delete the files used for Chooser
        deleteFiles(tempEntityDir);
        return false;
    }// end chooseEntity()
    // delete the tempfiles used for Chooser
    void deleteFiles(File directory){
        if(directory == null)return;
        String[]entries = directory.list();
        for(String s: entries){
            File currentFile = new File(directory.getPath(),s);
            currentFile.delete();
        }
    }// end deleteFiles()
       
    /** "PolyMap" is a HashMap of ArrayLists
     * insert one PolyMap entry with key 'actorReference'
     * 'Plus" version also keeps a master HashMap of all actorReferences
     * This version is for HashMap systemMap and systemMapPlus
     * returns true if the actorReference already is in systemName list
     * otherwise false
     */
    static HashMap<String,ArrayList<String>> systemMap = 
        new HashMap<String,ArrayList<String>>();
    static HashMap<String, String> systemMapPlus =
        new HashMap<String, String>();
    static boolean putPolyMapPlus(
        String systemName, String actorReference){
        // if PolyMapN contains entry keyed to 'systemName',
        // add this systemMessageType to ArrayList for the association 
        ArrayList<String> tryList = systemMap.get(systemName);
        if(tryList == null)tryList = new ArrayList<String>();
        boolean checkDup = tryList.indexOf(actorReference) >= 0;
        tryList.add(actorReference);
        systemMap.put(systemName,tryList);
        if(!checkDup)systemMapPlus.put(actorReference, systemName);
        return checkDup;
    }// end putPolyMapPlus()
    
    // gets ArrayList matching systemName
    static ArrayList<String> getPolyMap(String systemName) {    
        ArrayList<String> result = systemMap.get(systemName);
        return result;
    }// end getPolyMapN()
    
    // gets systemName matching actorReference
    String getPolyMapPlus(String actorReference){
        return systemMapPlus.get(actorReference);
    }// end getPolyMapPlus()
    
    /**
     * read and process a C2SIMInitialization file
     * @return true if error found, otherwise false
     */
    boolean readTemplateFile()
    {
        printDebug("READING XML:"+xmlInitFilename);
        xmlInitContents = 
            readAnXmlFile(c2simInitTemplateLocation+"/"+xmlInitFilename);
        if(xmlInitContents.length() == 0)return true;
        return false;
    }// end readTemplateFile()
    
    /**
     * extract a segment of the C2SIMInitialization based on:
     * 1. the starting index for next segment
     * 2. the XML tag that ends the segment
     * 
     * Used before editing Entities.
     * 
     * returns XML in range if endTag is found; "" otherwise
     * advances xmlStartIndex to character after endTag if it is found
     */
    String extractXml(String endTag)
    {
        int xmlEndIndex = xmlInitContents.lastIndexOf(endTag);
        if(xmlEndIndex < 0){
            showInfoPopup(true,"XML INPUT ERROR","MISSING END TAG " + 
            endTag + " IN C2SIMInitialize XML");
            return "";
        }
        int oldStartIndex = xmlStartIndex;
        xmlStartIndex = xmlEndIndex + endTag.length();
        return xmlInitContents.substring(oldStartIndex,xmlStartIndex);
    }// end extractXml()
    
   /**
     * extract the ActorReferences in each SystemEntityList and
     * store them mapped to the SystemName can be retrieved for each
     * 
     * Used before editing entities.
     * 
     * returns true if the SystemENtityList is not well formed
     */
    boolean extractSims()
    {
        // loop through all SystemEntityLists
        int systemNameIndex = 0;
        int systemEntityListIndex = 0;
        int systemEntityListEndIndex = 0;
        while(true){
            
            // find the next SystemEntityList start and end
            systemEntityListIndex = xmlSystemEntityLists.
                indexOf("<SystemEntityList>", systemEntityListEndIndex);
            if(systemEntityListIndex < 0)break; // no more lists
            systemEntityListEndIndex = xmlSystemEntityLists.
                indexOf("</SystemEntityList>", systemEntityListIndex);
            if(systemEntityListEndIndex < 0){
                showInfoPopup(true,"XML INPUT ERROR",
                    "MISSING SYSTEM ENTITY LIST END TAG </SystemEntityList> IN TEMPLATE XML");
                return true;
            }
            
            // find the next SystemName
            systemNameIndex = xmlSystemEntityLists.
                indexOf("<SystemName>", systemEntityListIndex);
            if(systemNameIndex < 0)return true;
            int systemNameEndIndex = xmlSystemEntityLists.
                indexOf("</SystemName>", systemNameIndex);
            if(systemEntityListEndIndex < 0){
                showInfoPopup(true,
                    "XML INPUT ERROR","MISSING SYSTEM NAME END TAG </SystemName> IN TEMPLATE XML");
                return true;
            }
            String systemName = 
                xmlSystemEntityLists.substring(systemNameIndex+12, systemNameEndIndex);
            
            // extract all ActorReference in this SystementityList and enter in HashMap
            int actorRefIndex  = systemEntityListIndex;
            int actorRefEndIndex = 0;
            while(true){
                actorRefIndex = 
                    xmlSystemEntityLists.indexOf("<ActorReference>", actorRefIndex);
                if(actorRefIndex < 0 || actorRefIndex > systemNameIndex)
                    break; // no more ActorRefs this list
                actorRefEndIndex = 
                    xmlSystemEntityLists.indexOf("</ActorReference>", actorRefIndex);
                if(actorRefEndIndex < 0){
                    showInfoPopup(true,
                        "XML INPUT ERROR","MISSING ACTOR REFERENCE END TAG " + 
                        "</ActorReference> IN TEMPLATE XML");
                    return true;
                }
                String actorRef = xmlSystemEntityLists.substring(actorRefIndex+16, 
                    actorRefEndIndex);
                actorRefIndex = actorRefEndIndex;
                
                // add the actorRef to the HashMap
                if(putPolyMapPlus(systemName,actorRef)){
                    showInfoPopup(true,
                        "XML INPUT ERROR","DUPLICATE ACTOR REFERENCE " + 
                        actorRef +" FOR SYSTEM NAME " + systemName + 
                        " IN TEMPLATE XML");
                    return true;
                }
            }
            if(actorRefIndex < 0)return false;
        }     
        return true;
    }// end extractSims()
    
    /**
     * build a C2SIMInitialization file from pieces extracted at startup
     * plus new <Entity> data entered in this run
     */
    static void createInitFile()
    {
        if(!initHasStarted)return;
        if(jaxFrontRunning){
            
        }
        printDebug("systemMap has " + systemMap.size() + " system entries");
    }
    
    /**
     * print argument only if in debug mode
     */
    static void printDebug(String toPrint)
    {
      if(debugMode)System.out.println(toPrint);
    }
    static void printDebug(int toPrint)
    {
      if(debugMode)System.out.println(toPrint);
    }
    static void printError(String toPrint)
    {
      if(debugMode)System.out.println("ERROR:"+toPrint);
    }
    
    /**
     * displays popup and prints info message 
     */
    public static void showInfoPopup(boolean error,
        String frameMessage, String infoMessage){
        JOptionPane.showMessageDialog(
            init, 
            infoMessage, 
            frameMessage,
            JOptionPane.INFORMATION_MESSAGE);
        if(error)printError(infoMessage + "|" + frameMessage);
        
    }// end showInfoPopup()
    
    /**
     * creates input dialog popup
     * returns new value 
     * returns zero if user selects cancel
     */
    static String inputTextPopup(String popupText){
        String answer = JOptionPane.showInputDialog(  
            init, popupText, "");
        return answer;
    }// end inputTextPopup()
    
    /**
     * creates input dialog popup
     * returns new value 
     * returns zero if user selects cancel
     */
    int yesNoPopup(String popupText){       
        int answer =
            JOptionPane.showConfirmDialog(init,
             "delete some Entity?","DELETE AN ENTITY",
            JOptionPane.YES_NO_OPTION);
        return answer;       
    }// end yesNoPopup()
    int keepEntityPopup(String popupText){      
        int answer =
            JOptionPane.showConfirmDialog(init,
             "keep it?","KEEP ENTITY",
            JOptionPane.YES_NO_OPTION);
        printDebug("YES KEEP ENTITY");
        return answer;     
    }// end keepEntityPopup()
    static int saveFilePopup(String popupText){       
        int answer =
            JOptionPane.showConfirmDialog(init,
             "save edited file?","SAVE INIT FILE",
            JOptionPane.YES_NO_OPTION);
        return answer;     
    }// end saveFilePopup()    
    
    /**
     * reads an XML file from the file system 
     * @param xmlUrl
     * @return file contents
     */
    public String readAnXmlFile(URL xmlUrl){
        return readAnXmlFile(xmlUrl.toString().substring(6));
    }
    public String readAnXmlFile(String xmlFilename) {
        // correct pathological path bug
        if(xmlFilename.charAt(0) != '.')
            if(xmlFilename.charAt(0) != '/')
                xmlFilename = "/" + xmlFilename;
        // read the file
        FileReader xmlFile;
        String xmlString = "";
        try{
          xmlFile=new FileReader(new File(xmlFilename));
          int charBuf; 
          while((charBuf=xmlFile.read())>0) {
            xmlString+=(char)charBuf;
          }
        }
        catch(FileNotFoundException fnfe){
          printError("file " + xmlFilename + 
            " not found - returning empty string");
          return "";
        }
        catch(Exception e) {
          printError("Exception in reading XML file " + 
            xmlFilename + ":"+e);
          e.printStackTrace();
          return "";
        }
        return xmlString;
  
    }// end readAnXmlFile()
    
}// end C2SIMinit class
